# Informasi Keystore & Keamanan Aplikasi RT03

## Kredensial Keystore (untuk signing APK release)
- **File Keystore**: `rt03-release.jks` (dapat diletakkan di folder `app/`)
- **Store Password**: `rt031234`
- **Key Alias**: `rt03key`
- **Key Password**: `rt031234`

## Panduan Instalasi:
1. Pastikan file `settings.gradle` dan `build.gradle` berada di tingkat paling luar (root) sebelum di-build di AndroidForge.
2. Jika Play Protect memberikan peringatan saat instalasi manual, ketuk "Detail selengkapnya" -> "Tetap instal".
