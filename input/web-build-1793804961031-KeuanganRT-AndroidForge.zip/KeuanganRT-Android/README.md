# Keuangan RT — Android WebView Project

Project Android siap build untuk **AndroidForge**.

## Langkah penting sebelum build

1. **Ganti URL deployment** di file:
   ```
   app/src/main/res/values/strings.xml
   ```
   Cari baris:
   ```xml
   <string name="web_app_url">https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec</string>
   ```
   Ganti dengan URL Web App Google Apps Script kamu (yang sudah di-Deploy as web app).

2. (Opsional) Ubah `applicationId` dan nama package jika ingin package name berbeda:
   - `app/build.gradle` → `applicationId`
   - Folder `java/com/rt03/keuangan` + package di `MainActivity.java`
   - `AndroidManifest.xml` namespace sudah mengikuti `build.gradle`

## Build di AndroidForge

1. Zip seluruh isi folder ini (file `settings.gradle`, `app/`, `gradle/` dll harus di root ZIP).
2. Upload ZIP ke https://professional-x.github.io/AndroidForge/
3. Pilih build variant **debug** (atau release jika sudah ada keystore).
4. Setelah selesai, unduh APK dari GitHub Actions artifact.

## Catatan

- Aplikasi ini memuat halaman Google Apps Script di WebView.
- JavaScript, Cookie, dan LocalStorage diaktifkan agar login & notifikasi FCM tetap berfungsi.
- Pastikan Web App di GAS di-deploy dengan akses **"Anyone"** (atau "Anyone with Google account") agar bisa dibuka dari APK.
- Untuk push notification FCM, pastikan service account / OAuth di GAS sudah benar (seperti di Code.gs).
