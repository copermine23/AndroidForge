@file:OptIn(ExperimentalMaterial3Api::class)

package com.rt03.warga

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.time.YearMonth

val Green = Color(0xFF14532D)
val GreenL = Color(0xFF166534)
val RedC = Color(0xFFB42318)
val BgC = Color(0xFFEAF6EF)
val OkTint = Color(0xFFDCFCE7)
val BadTint = Color(0xFFFEE2E2)
val WarnTint = Color(0xFFFEF3C7)

val ROLE_LABEL = mapOf("admin" to "Admin", "operator" to "Operator", "viewer" to "Viewer", "warga" to "Warga / KK")

@Composable
fun RtTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = lightColorScheme(primary = GreenL, onPrimary = Color.White, secondary = Green, background = BgC, surface = Color.White),
    content = content
)

// ---------- widget umum ----------
@Composable
fun Card2(modifier: Modifier = Modifier, tint: Color = Color.White, content: @Composable ColumnScope.() -> Unit) =
    Card(colors = CardDefaults.cardColors(containerColor = tint), modifier = modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp), content = content)
    }

@Composable fun Muted(t: String) = Text(t, fontSize = 12.sp, color = Color(0xFF55675C))
@Composable fun Title(t: String) = Text(t, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 6.dp))

@Composable
fun Metric(label: String, value: String, tint: Color = Color.White, valueColor: Color = Color.Unspecified, modifier: Modifier = Modifier) =
    Card(colors = CardDefaults.cardColors(containerColor = tint), modifier = modifier.padding(vertical = 4.dp)) {
        Column(Modifier.padding(12.dp)) {
            Muted(label)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = valueColor)
        }
    }

@Composable
fun Field(label: String, value: String, onChange: (String) -> Unit, keyboard: KeyboardType = KeyboardType.Text,
          password: Boolean = false, singleLine: Boolean = true, modifier: Modifier = Modifier) =
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) }, singleLine = singleLine,
        visualTransformation = if (password) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        modifier = modifier.fillMaxWidth().padding(vertical = 3.dp)
    )

@Composable
fun Pick(label: String, value: String, options: List<Pair<String, String>>, onPick: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box(Modifier.padding(vertical = 3.dp)) {
        OutlinedButton(onClick = { open = true }, modifier = Modifier.fillMaxWidth()) {
            Text("$label: ${options.find { it.first == value }?.second ?: "—"}", maxLines = 1)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            options.forEach { (v, l) -> DropdownMenuItem(text = { Text(l) }, onClick = { onPick(v); open = false }) }
        }
    }
}

@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit) =
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { o -> FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(o) }) }
    }

@Composable
fun Confirm(text: String, onYes: () -> Unit, onNo: () -> Unit) = AlertDialog(
    onDismissRequest = onNo, text = { Text(text) },
    confirmButton = { TextButton(onClick = onYes) { Text("Ya") } },
    dismissButton = { TextButton(onClick = onNo) { Text("Batal") } }
)

@Composable
fun MonthNav(m: String, onChange: (String) -> Unit) = Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
    TextButton(onClick = { onChange(shiftMonth(m, -1)) }) { Text("◀") }
    Text(m, fontWeight = FontWeight.Bold)
    TextButton(onClick = { onChange(shiftMonth(m, 1)) }) { Text("▶") }
}
fun shiftMonth(m: String, d: Int): String = try { YearMonth.parse(m).plusMonths(d.toLong()).toString() } catch (e: Exception) { Rt.monthNow() }

// ---------- aplikasi ----------
@Composable
fun RtApp(vm: AppVm) = RtTheme {
    Surface(Modifier.fillMaxSize(), color = BgC) {
        if (!vm.loggedIn) LoginScreen(vm) else MainScreen(vm)
        if (vm.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        vm.message?.let { m ->
            AlertDialog(onDismissRequest = { vm.message = null }, text = { Text(m) },
                confirmButton = { TextButton(onClick = { vm.message = null }) { Text("OK") } })
        }
        vm.secret?.let { (t, s) ->
            AlertDialog(onDismissRequest = { vm.secret = null }, title = { Text(t) },
                text = { Column { Muted("Bagikan secara pribadi. Hanya ditampilkan sekali."); Spacer(Modifier.height(8.dp))
                    SelectionContainer { Text(s, fontSize = 18.sp, fontWeight = FontWeight.Bold) } } },
                confirmButton = { TextButton(onClick = { vm.secret = null }) { Text("Selesai") } })
        }
        if (vm.showChangePw && vm.loggedIn) ChangePwDialog(vm)
    }
}

@Composable
fun LoginScreen(vm: AppVm) {
    var u by remember { mutableStateOf("") }
    var p by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("Keuangan RT", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Green)
        Muted("Catat kas, iuran, dan laporan warga")
        Spacer(Modifier.height(20.dp))
        Card2 {
            Title("Masuk Aplikasi RT")
            Muted("Pengurus masuk dengan username dan password. Warga masuk dengan nomor HP terdaftar dan PIN 6 angka.")
            Field("Nomor HP / Username", u, { u = it })
            Field("PIN / Password", p, { p = it }, password = true)
            Spacer(Modifier.height(8.dp))
            Button(onClick = { vm.login(u, p) }, enabled = !vm.busy && u.isNotBlank() && p.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("Masuk") }
        }
    }
}

@Composable
fun ChangePwDialog(vm: AppVm) {
    var lama by remember { mutableStateOf("") }
    var baru by remember { mutableStateOf("") }
    val w = vm.isWarga
    val valid = if (w) Regex("^\\d{6}$").matches(baru) else baru.length >= 10
    AlertDialog(
        onDismissRequest = { if (!vm.temp) vm.showChangePw = false },
        title = { Text(if (w) "Ganti PIN" else "Ganti password saya") },
        text = { Column {
            if (vm.temp) Muted("Ini adalah sandi sementara. Buat sandi pribadi sekarang.")
            Field(if (w) "PIN lama" else "Password lama", lama, { lama = it }, password = true, keyboard = if (w) KeyboardType.NumberPassword else KeyboardType.Password)
            Field(if (w) "PIN baru (6 angka)" else "Password baru (min. 10 karakter)", baru, { baru = it }, password = true, keyboard = if (w) KeyboardType.NumberPassword else KeyboardType.Password)
        } },
        confirmButton = { TextButton(onClick = { vm.gantiPassword(lama, baru) }, enabled = lama.isNotEmpty() && valid) { Text("Simpan") } },
        dismissButton = { if (!vm.temp) TextButton(onClick = { vm.showChangePw = false }) { Text("Batal") } }
    )
}

@Composable
fun MainScreen(vm: AppVm) {
    var tab by rememberSaveable { mutableStateOf("home") }
    val tabs = if (vm.isWarga) listOf("home", "iuran", "laporan", "lain") else listOf("home", "warga", "transaksi", "iuran", "laporan", "lain")
    if (tab !in tabs) tab = "home"
    LaunchedEffect(vm.token) { while (true) { delay(30_000); vm.load() } }
    fun label(t: String) = mapOf("home" to "Beranda", "warga" to "Warga", "transaksi" to "Transaksi", "iuran" to "Iuran", "laporan" to "Laporan", "lain" to "Lainnya")[t] ?: t
    fun icon(t: String): ImageVector = when (t) {
        "home" -> Icons.Default.Home; "warga" -> Icons.Default.Person; "transaksi" -> Icons.Default.Add
        "iuran" -> Icons.AutoMirrored.Filled.List; "laporan" -> Icons.Default.DateRange; else -> Icons.Default.Menu
    }
    Scaffold(
        topBar = {
            Column(Modifier.fillMaxWidth().background(Green).padding(horizontal = 16.dp, vertical = 12.dp)) {
                Text("APLIKASI PEMBUKUAN WARGA", color = Color(0xFFBBF7D0), fontSize = 10.sp)
                Text("Keuangan RT", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Text(vm.status, color = Color(0xFFDCFCE7), fontSize = 11.sp)
                Text("Masuk: ${vm.user} (${ROLE_LABEL[vm.role] ?: vm.role})", color = Color.White, fontSize = 11.sp)
            }
        },
        bottomBar = {
            NavigationBar {
                tabs.forEach { t ->
                    NavigationBarItem(selected = tab == t, onClick = { tab = t }, icon = { Icon(icon(t), null) },
                        label = { Text(label(t), fontSize = 10.sp, maxLines = 1) })
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            val db = vm.db
            if (db == null) {
                Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(); Spacer(Modifier.height(8.dp)); Muted("Memuat data…")
                    TextButton(onClick = { vm.logout() }) { Text("Masuk ulang") }
                }
            } else when (tab) {
                "home" -> HomeScreen(vm, db)
                "warga" -> WargaScreen(vm, db)
                "transaksi" -> TransaksiScreen(vm, db)
                "iuran" -> IuranScreen(vm, db)
                "laporan" -> LaporanScreen(db)
                else -> LainScreen(vm, db)
            }
        }
    }
}
