Keuangan RT — proyek Android WebView untuk AndroidForge

Cara pakai di AndroidForge:
1. Upload ZIP ini (seluruh isi folder / file zip proyek).
2. Pastikan AndroidForge mendeteksi sebagai proyek Android/Gradle.
3. Build APK (assembleDebug atau assembleRelease).

URL aplikasi sudah tertanam di MainActivity.java.
Jika URL deployment Apps Script berubah, edit:
  app/src/main/java/com/rt/keuangan/MainActivity.java
  konstanta APP_URL

Package: com.rt.keuangan
Min SDK: 24 | Target SDK: 34
