# Keep WebView
-keepclassmembers class * extends android.webkit.WebViewClient { *; }
