# Keuangan RT — Proyek Android untuk AndroidForge

Proyek Android native sederhana berbasis WebView. Aplikasi membuka deployment Google Apps Script yang sudah ditautkan di `app/src/main/java/id/rtkeuangan/app/MainActivity.java`.

## Tetap online (bukan aplikasi offline)
- Aplikasi memerlukan koneksi internet.
- URL web app Apps Script sudah disematkan di dalam aplikasi.
- Login, data warga, transaksi, pembayaran, laporan, dan database bersama tetap dijalankan oleh Google Apps Script / Google Drive.
- HTML tidak dibundel sebagai halaman offline karena `google.script.run` harus berjalan dari deployment Google Apps Script.
- Jika URL deployment berubah, ubah konstanta `APP_URL` pada `MainActivity.java`, lalu build ulang.

## Build dengan AndroidForge
1. Buka AndroidForge: https://professional-x.github.io/AndroidForge/
2. Impor/unggah ZIP proyek ini sesuai alur AndroidForge.
3. Pastikan `settings.gradle` berada di direktori paling atas proyek.
4. Pilih platform Android dan build variant `debug` atau `auto` jika tersedia.
5. Jalankan build dan unduh APK hasil build.

## Pengaturan proyek
- Nama aplikasi: Keuangan RT
- Application ID: `id.rtkeuangan.app`
- Minimum Android: Android 6.0 (API 23)
- Compile SDK: API 34
- Versi: 1.0.0

## Fitur WebView yang disiapkan
- JavaScript, DOM storage, cookie pihak ketiga, dan sesi login.
- Navigasi redirect Google Apps Script tetap di dalam aplikasi.
- Pemilih file untuk pemulihan backup.
- Unduhan laporan dan backup.
- Dukungan jendela cetak kuitansi melalui layanan cetak Android.

## Catatan
ZIP ini adalah source project untuk dibuild, bukan APK yang sudah ditandatangani. Setelah build, uji login, penyimpanan data, backup/pemulihan, unduhan laporan, dan cetak kuitansi pada perangkat Android.
