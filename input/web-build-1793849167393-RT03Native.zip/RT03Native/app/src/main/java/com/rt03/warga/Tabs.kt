@file:OptIn(ExperimentalMaterial3Api::class)

package com.rt03.warga

import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONObject

private val pad = PaddingValues(12.dp)
private fun sortTx(l: List<JSONObject>) = l.sortedWith(compareByDescending<JSONObject> { it.str("tanggal") }.thenByDescending { it.str("id") })

// =============== BERANDA ===============
@Composable
fun HomeScreen(vm: AppVm, db: JSONObject) {
    var showAnn by remember { mutableStateOf(false) }
    var editAnn by remember { mutableStateOf<JSONObject?>(null) }
    var delAnn by remember { mutableStateOf<JSONObject?>(null) }
    val settings = db.optJSONObject("settings") ?: JSONObject()
    val year = settings.optInt("tahun", 2026).toString()
    val (mi, mo) = Rt.monthTotals(db, Rt.monthNow())
    val anns = db.list("pengumuman").sortedByDescending { it.str("dibuatPada").ifEmpty { it.str("tanggal") } }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { Metric("Saldo kas saat ini", Rt.rup(Rt.saldoKas(db)), modifier = Modifier.fillMaxWidth()) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Total pemasukan", Rt.rup(Rt.income(db)), OkTint, Color(0xFF16803D), Modifier.weight(1f))
                Metric("Total pengeluaran", Rt.rup(Rt.expense(db)), BadTint, RedC, Modifier.weight(1f))
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Masuk bulan ini", Rt.rup(mi), modifier = Modifier.weight(1f))
                Metric("Keluar bulan ini", Rt.rup(mo), modifier = Modifier.weight(1f))
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Title("📢 Pengumuman RT")
                if (vm.canEdit) Button(onClick = { editAnn = null; showAnn = true }) { Text("Tambah") }
            }
        }
        if (anns.isEmpty()) item { Card2 { Muted("Belum ada pengumuman.") } }
        items(anns) { a ->
            Card2 {
                Text(a.str("judul"), fontWeight = FontWeight.Bold)
                Muted(a.str("tanggal") + if (a.str("pembuat").isNotEmpty()) " · ${a.str("pembuat")}" else "")
                Spacer(Modifier.height(4.dp)); Text(a.str("isi"))
                if (vm.canEdit) Row {
                    TextButton(onClick = { editAnn = a; showAnn = true }) { Text("Edit") }
                    TextButton(onClick = { delAnn = a }) { Text("Hapus", color = RedC) }
                }
            }
        }
        item { Title("Saldo kas per kategori · $year") }
        items(Rt.categoryBalances(db, year)) { c ->
            Card2 {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(c.kategori, fontWeight = FontWeight.Bold)
                    Text(Rt.rup(c.saldo), fontWeight = FontWeight.ExtraBold, color = if (c.saldo < 0) RedC else Color(0xFF16803D))
                }
                Muted("Awal ${Rt.rup(c.awal)} · Masuk ${Rt.rup(c.masuk)} · Keluar ${Rt.rup(c.keluar)}")
            }
        }
    }
    if (showAnn) AnnDialog(vm, editAnn) { showAnn = false }
    delAnn?.let { a ->
        Confirm("Hapus pengumuman ini?", {
            vm.mutate { d -> d.ensureArr("pengumuman").removeWhere { it.str("id") == a.str("id") } }; delAnn = null
        }, { delAnn = null })
    }
}

@Composable
fun AnnDialog(vm: AppVm, edit: JSONObject?, onClose: () -> Unit) {
    var judul by remember { mutableStateOf(edit?.str("judul") ?: "") }
    var isi by remember { mutableStateOf(edit?.str("isi") ?: "") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(if (edit == null) "Pengumuman baru" else "Edit pengumuman") },
        text = { Column {
            Field("Judul *", judul, { judul = it.take(120) })
            Field("Isi pengumuman *", isi, { isi = it.take(3000) }, singleLine = false)
        } },
        confirmButton = {
            TextButton(enabled = judul.isNotBlank() && isi.isNotBlank(), onClick = {
                vm.mutate("Pengumuman tersimpan dan dapat dilihat seluruh warga.") { d ->
                    val arr = d.ensureArr("pengumuman")
                    val row = edit?.let { e -> arr.items().find { it.str("id") == e.str("id") } }
                    if (row != null) { row.put("judul", judul.trim()); row.put("isi", isi.trim()); row.put("diperbaruiPada", Rt.dateNow()) }
                    else arr.put(JSONObject().put("id", Rt.newId("ANN")).put("judul", judul.trim()).put("isi", isi.trim())
                        .put("tanggal", Rt.dateNow()).put("dibuatPada", java.time.Instant.now().toString()).put("pembuat", vm.user.ifEmpty { "Pengurus RT" }))
                }
                onClose()
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } }
    )
}

// =============== WARGA ===============
@Composable
fun WargaScreen(vm: AppVm, db: JSONObject) {
    var q by remember { mutableStateOf("") }
    var form by remember { mutableStateOf(false) }
    var editW by remember { mutableStateOf<JSONObject?>(null) }
    var detail by remember { mutableStateOf<String?>(null) }
    var del by remember { mutableStateOf<JSONObject?>(null) }
    val list = db.list("warga").filter { (it.str("nama") + it.str("alamat") + it.str("hp")).contains(q, true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            Field("Cari nama / alamat / HP", q, { q = it })
            if (vm.canEdit) Button(onClick = { editW = null; form = true }, modifier = Modifier.fillMaxWidth()) { Text("Tambah warga") }
            Muted("${Rt.activeWarga(db).size} KK aktif dari ${db.list("warga").size} KK")
        }
        if (list.isEmpty()) item { Card2 { Muted("Belum ada data warga.") } }
        items(list) { w ->
            Card2(Modifier.clickable { detail = w.str("id") }, tint = if (w.str("status") == "Nonaktif") Color(0xFFF1F5F2) else Color.White) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(w.str("nama"), fontWeight = FontWeight.Bold)
                    Text(w.str("status").ifEmpty { "Aktif" }, fontSize = 12.sp, color = Green)
                }
                Muted("${w.str("id")} · ${w.str("alamat").ifEmpty { "-" }} · ${w.str("hp").ifEmpty { "tanpa HP" }}")
                if (vm.canEdit) Row {
                    TextButton(onClick = { editW = w; form = true }) { Text("Edit") }
                    TextButton(onClick = { del = w }) { Text("Hapus", color = RedC) }
                }
            }
        }
    }
    if (form) WargaForm(vm, editW) { form = false }
    detail?.let { WargaDetail(db, it) { detail = null } }
    del?.let { w ->
        Confirm("Hapus data warga ini? Transaksi lama tidak ikut dihapus.", {
            vm.mutate("Data warga dihapus.") { d -> d.ensureArr("warga").removeWhere { it.str("id") == w.str("id") } }; del = null
        }, { del = null })
    }
}

@Composable
fun WargaForm(vm: AppVm, edit: JSONObject?, onClose: () -> Unit) {
    var nama by remember { mutableStateOf(edit?.str("nama") ?: "") }
    var alamat by remember { mutableStateOf(edit?.str("alamat") ?: "") }
    var hp by remember { mutableStateOf(edit?.str("hp") ?: "") }
    var tgl by remember { mutableStateOf(edit?.str("tanggal") ?: Rt.dateNow()) }
    var status by remember { mutableStateOf(edit?.str("status")?.ifEmpty { "Aktif" } ?: "Aktif") }
    var anggota by remember { mutableStateOf(edit?.str("anggota") ?: "") }
    var catatan by remember { mutableStateOf(edit?.str("catatan") ?: "") }
    AlertDialog(
        onDismissRequest = onClose, title = { Text(if (edit == null) "Tambah warga" else "Edit warga") },
        text = { Column(Modifier.verticalScrollCompat()) {
            Field("Nama kepala keluarga *", nama, { nama = it })
            Field("Alamat", alamat, { alamat = it })
            Field("Nomor HP", hp, { hp = it }, KeyboardType.Phone)
            Field("Tanggal bergabung (yyyy-mm-dd)", tgl, { tgl = it })
            ChipRow(listOf("Aktif", "Nonaktif"), status) { status = it }
            Field("Nama anggota / penerima", anggota, { anggota = it })
            Field("Catatan", catatan, { catatan = it })
        } },
        confirmButton = {
            TextButton(enabled = nama.isNotBlank(), onClick = {
                vm.mutate("Data warga tersimpan.") { d ->
                    val arr = d.ensureArr("warga")
                    val row = edit?.let { e -> arr.items().find { it.str("id") == e.str("id") } }
                        ?: JSONObject().put("id", Rt.newId("KK")).put("iuran", 0).also { arr.put(it) }
                    row.put("nama", nama.trim()).put("alamat", alamat).put("hp", hp).put("tanggal", tgl)
                        .put("status", status).put("anggota", anggota).put("catatan", catatan)
                }
                onClose()
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } }
    )
}

@Composable
fun Modifier.verticalScrollCompat(): Modifier =
    this.then(Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState()))

@Composable
fun WargaDetail(db: JSONObject, wid: String, onClose: () -> Unit) {
    val w = db.list("warga").find { it.str("id") == wid } ?: run { onClose(); return }
    var m by remember { mutableStateOf(Rt.monthNow()) }
    val hist = sortTx(db.list("transaksi").filter { it.str("wargaId") == wid && it.str("jenis") == "Pemasukan" }).take(10)
    AlertDialog(
        onDismissRequest = onClose, title = { Text(w.str("nama")) },
        confirmButton = { TextButton(onClick = onClose) { Text("Tutup") } },
        text = { Column(Modifier.verticalScrollCompat()) {
            Muted("${w.str("id")} · ${w.str("alamat").ifEmpty { "-" }}")
            MonthNav(m) { m = it }
            Rt.DUES_CATS.forEach { k ->
                (if (k == "Arisan Ngaji") listOf("$m-1", "$m-2") else listOf(m)).forEach { p ->
                    if (Rt.isLibur(db, k, p)) {
                        Card2(tint = WarnTint) { Text(k, fontWeight = FontWeight.Bold); Muted("${Rt.periodLabel(k, p)} · Libur, tidak ditagihkan") }
                    } else {
                        val r = Rt.duesOf(db, k, p).find { it.warga.str("id") == wid }
                        val (txt, tint) = when {
                            r == null -> "Tidak ditagih" to Color.White
                            r.left == 0.0 -> "Lunas" to OkTint
                            r.paid > 0 -> "Sebagian" to WarnTint
                            else -> "Belum bayar" to BadTint
                        }
                        Card2(tint = tint) {
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k, fontWeight = FontWeight.Bold); Text(txt, fontSize = 12.sp) }
                            Muted(Rt.periodLabel(k, p) + (r?.let { " · Tagihan ${Rt.rup(it.tagihan)} · Dibayar ${Rt.rup(it.paid)}" + if (it.left > 0) " · Sisa ${Rt.rup(it.left)}" else "" } ?: ""))
                            if (r != null && r.tglLunas.isNotEmpty()) Muted("✓ Lunas tanggal ${r.tglLunas}")
                        }
                    }
                }
            }
            Title("Riwayat pembayaran terakhir")
            if (hist.isEmpty()) Muted("Belum ada pembayaran.")
            hist.forEach { t -> Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text(t.str("kategori")); Muted(t.str("tanggal")) }
                Text(Rt.rup(t.num("nominal")), color = Color(0xFF16803D), fontWeight = FontWeight.Bold)
            } }
        } }
    )
}

// =============== TRANSAKSI ===============
@Composable
fun TransaksiScreen(vm: AppVm, db: JSONObject) {
    var q by remember { mutableStateOf("") }
    var form by remember { mutableStateOf(false) }
    var del by remember { mutableStateOf<JSONObject?>(null) }
    val list = sortTx(db.list("transaksi").filter { (it.str("uraian") + it.str("kategori") + it.str("tanggal")).contains(q, true) })
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            Field("Cari transaksi", q, { q = it })
            if (vm.canEdit) Button(onClick = { form = true }, modifier = Modifier.fillMaxWidth()) { Text("Catat transaksi") }
        }
        if (list.isEmpty()) item { Card2 { Muted("Belum ada transaksi.") } }
        items(list.take(200)) { t ->
            val masuk = t.str("jenis") == "Pemasukan"
            Card2(tint = if (masuk) OkTint else BadTint) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(t.str("uraian"), fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text((if (masuk) "+ " else "− ") + Rt.rup(t.num("nominal")), fontWeight = FontWeight.ExtraBold, color = if (masuk) Color(0xFF16803D) else RedC)
                }
                Muted(listOf(t.str("tanggal"), t.str("kategori"), t.str("sumberDana").let { if (it.isEmpty()) "" else "Dana: $it" },
                    t.str("metode"), t.str("periode")).filter { it.isNotEmpty() }.joinToString(" · "))
                if (vm.canEdit) TextButton(onClick = { del = t }) { Text("Hapus", color = RedC) }
            }
        }
        if (list.size > 200) item { Muted("Menampilkan 200 transaksi terbaru. Gunakan pencarian untuk yang lain.") }
    }
    if (form) TxDialog(vm, db) { form = false }
    del?.let { t ->
        Confirm("Hapus transaksi ini?", {
            vm.mutate("Transaksi dihapus.") { d -> d.ensureArr("transaksi").removeWhere { it.str("id") == t.str("id") } }; del = null
        }, { del = null })
    }
}

@Composable
fun TxDialog(vm: AppVm, db: JSONObject, onClose: () -> Unit) {
    var jenis by remember { mutableStateOf("Pemasukan") }
    var tgl by remember { mutableStateOf(Rt.dateNow()) }
    var kat by remember { mutableStateOf(Rt.IN_CATS[0]) }
    var sumber by remember { mutableStateOf("") }
    var wid by remember { mutableStateOf("") }
    var periode by remember { mutableStateOf(Rt.monthNow()) }
    var paruh by remember { mutableStateOf(Rt.paruhNow().toString()) }
    var uraian by remember { mutableStateOf("") }
    var nominal by remember { mutableStateOf("") }
    var metode by remember { mutableStateOf("Tunai") }
    var warn by remember { mutableStateOf<String?>(null) }
    val masuk = jenis == "Pemasukan"
    val isDues = masuk && kat in Rt.DUES_CATS
    val nom = nominal.toDoubleOrNull() ?: 0.0

    fun save() {
        val t = JSONObject().put("id", Rt.newId("TRX")).put("tanggal", tgl).put("jenis", jenis).put("kategori", kat)
            .put("sumberDana", if (masuk) "" else sumber).put("wargaId", if (masuk) wid else "")
            .put("periode", if (isDues) (if (kat == "Arisan Ngaji") "$periode-$paruh" else periode) else "")
            .put("uraian", uraian.trim()).put("nominal", nom).put("metode", metode).put("pencatat", vm.user)
        vm.mutate("Transaksi tersimpan.") { d -> d.ensureArr("transaksi").put(t) }
        onClose()
    }

    AlertDialog(
        onDismissRequest = onClose, title = { Text("Catat transaksi") },
        text = { Column(Modifier.verticalScrollCompat()) {
            ChipRow(listOf("Pemasukan", "Pengeluaran"), jenis) { jenis = it; kat = if (it == "Pemasukan") Rt.IN_CATS[0] else Rt.OUT_CATS[0] }
            Field("Tanggal (yyyy-mm-dd)", tgl, { tgl = it })
            Pick("Kategori", kat, (if (masuk) Rt.IN_CATS else Rt.OUT_CATS).map { it to it }) { kat = it }
            if (!masuk) Pick("Sumber dana", sumber, Rt.IN_CATS.map { it to it }) { sumber = it }
            if (masuk) Pick("Warga (opsional)", wid, listOf("" to "—") + db.list("warga").map { it.str("id") to it.str("nama") }) { wid = it }
            if (isDues) {
                Field("Periode (yyyy-mm)", periode, { periode = it })
                if (kat == "Arisan Ngaji") ChipRow(listOf("1", "2"), paruh) { paruh = it }
            }
            Field("Uraian *", uraian, { uraian = it })
            Field("Nominal (Rp) *", nominal, { nominal = it.filter { c -> c.isDigit() || c == '.' } }, KeyboardType.Number)
            Pick("Metode", metode, Rt.METHODS.map { it to it }) { metode = it }
        } },
        confirmButton = {
            TextButton(enabled = uraian.isNotBlank() && nom > 0 && tgl.length == 10 && (masuk || sumber.isNotEmpty()), onClick = {
                val c = if (masuk) null else Rt.categoryBalances(db, tgl.take(4)).find { it.kategori == sumber }
                if (c != null && nom > c.saldo) warn = "Saldo $sumber hanya ${Rt.rup(c.saldo)}. Pengeluaran ini membuat saldo kategori minus. Tetap simpan?"
                else save()
            }) { Text("Simpan") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Batal") } }
    )
    warn?.let { Confirm(it, { warn = null; save() }, { warn = null }) }
}

// =============== IURAN ===============
@Composable
fun IuranScreen(vm: AppVm, db: JSONObject) {
    var kat by remember { mutableStateOf(Rt.DUES_CATS[0]) }
    var m by remember { mutableStateOf(Rt.monthNow()) }
    var paruh by remember { mutableStateOf(Rt.paruhNow().toString()) }
    var libur by remember { mutableStateOf(false) }
    val p = if (kat == "Arisan Ngaji") "$m-$paruh" else m
    val isLibur = Rt.isLibur(db, kat, p)
    val dues = Rt.duesOf(db, kat, p).sortedWith(compareBy({ it.left == 0.0 }, { it.warga.str("nama") }))
    val lunas = dues.count { it.left == 0.0 }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            ChipRow(Rt.DUES_CATS, kat) { kat = it }
            MonthNav(m) { m = it }
            if (kat == "Arisan Ngaji") ChipRow(listOf("1", "2"), paruh) { paruh = it }
            Muted(Rt.periodLabel(kat, p))
            if (kat == "Arisan Ngaji" && vm.canEdit)
                OutlinedButton(onClick = { libur = true }) { Text(if (isLibur) "Batalkan libur periode ini" else "Tandai periode ini libur") }
        }
        if (isLibur) item { Card2(tint = WarnTint) { Text("Periode libur — warga tidak ditagih.", fontWeight = FontWeight.Bold) } }
        else {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Metric("Lunas", "$lunas / ${dues.size} KK", OkTint, modifier = Modifier.weight(1f))
                    Metric("Terkumpul", Rt.rup(dues.sumOf { it.paid }) + " dari " + Rt.rup(dues.sumOf { it.tagihan }), modifier = Modifier.weight(1f))
                }
            }
            if (dues.isEmpty()) item { Card2 { Muted("Tidak ada tagihan untuk periode ini. Atur tarif di Lainnya › Pengaturan.") } }
            items(dues) { d ->
                val (txt, tint) = when { d.left == 0.0 -> "Lunas" to OkTint; d.paid > 0 -> "Sebagian" to WarnTint; else -> "Belum bayar" to BadTint }
                Card2(tint = tint) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(d.warga.str("nama"), fontWeight = FontWeight.Bold); Text(txt, fontSize = 12.sp) }
                    Muted("Tagihan ${Rt.rup(d.tagihan)} · Dibayar ${Rt.rup(d.paid)}" + if (d.left > 0) " · Sisa ${Rt.rup(d.left)}" else "")
                    if (d.tglLunas.isNotEmpty()) Muted("✓ Lunas tanggal ${d.tglLunas}")
                }
            }
        }
    }
    if (libur) Confirm(
        if (isLibur) "Batalkan status libur ${Rt.periodLabel(kat, p)}? Warga akan ditagih lagi." else "Tandai ${Rt.periodLabel(kat, p)} sebagai LIBUR? Warga tidak akan ditagih.",
        {
            vm.mutate { d ->
                val s = d.ensureObj("settings"); val old = s.optJSONArray("liburArisan")
                val l = (0 until (old?.length() ?: 0)).map { old!!.optString(it) }.toMutableList()
                if (!l.remove(p)) l.add(p)
                s.put("liburArisan", org.json.JSONArray(l))
            }; libur = false
        }, { libur = false })
}

// =============== LAPORAN ===============
@Composable
fun LaporanScreen(db: JSONObject) {
    var m by remember { mutableStateOf(Rt.monthNow()) }
    val (mi, mo) = Rt.monthTotals(db, m)
    val awal = Rt.saldoAwalBulan(db, m)
    val tx = db.list("transaksi").filter { it.str("tanggal").startsWith(m) }
    val year = db.optJSONObject("settings")?.optInt("tahun", 2026)?.toString() ?: m.take(4)
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item { MonthNav(m) { m = it } }
        item {
            Metric("Saldo awal bulan", Rt.rup(awal), modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Metric("Pemasukan", Rt.rup(mi), OkTint, Color(0xFF16803D), Modifier.weight(1f))
                Metric("Pengeluaran", Rt.rup(mo), BadTint, RedC, Modifier.weight(1f))
            }
            Metric("Saldo akhir bulan", Rt.rup(awal + mi - mo), modifier = Modifier.fillMaxWidth())
        }
        item { Title("Pemasukan per kategori") }
        val inc = Rt.IN_CATS.map { k -> k to tx.filter { it.str("jenis") == "Pemasukan" && it.str("kategori") == k }.sumOf { it.num("nominal") } }.filter { it.second > 0 }
        if (inc.isEmpty()) item { Muted("Tidak ada pemasukan.") }
        items(inc) { (k, n) -> Card2(tint = OkTint) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k); Text(Rt.rup(n), fontWeight = FontWeight.Bold) } } }
        item { Title("Pengeluaran per kategori") }
        val exp = Rt.OUT_CATS.map { k -> k to tx.filter { it.str("jenis") == "Pengeluaran" && it.str("kategori") == k }.sumOf { it.num("nominal") } }.filter { it.second > 0 }
        if (exp.isEmpty()) item { Muted("Tidak ada pengeluaran.") }
        items(exp) { (k, n) -> Card2(tint = BadTint) { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(k); Text(Rt.rup(n), fontWeight = FontWeight.Bold, color = RedC) } } }
        item { Title("Saldo per kategori · $year") }
        items(Rt.categoryBalances(db, year)) { c ->
            Card2 { Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(c.kategori); Text(Rt.rup(c.saldo), fontWeight = FontWeight.Bold) }
                Muted("Awal ${Rt.rup(c.awal)} · Masuk ${Rt.rup(c.masuk)} · Keluar ${Rt.rup(c.keluar)}") }
        }
    }
}

// =============== LAINNYA ===============
@Composable
fun LainScreen(vm: AppVm, db: JSONObject) {
    var logoutAsk by remember { mutableStateOf(false) }
    LaunchedEffect(vm.role) { if (vm.isAdmin) vm.loadAccounts() }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = pad) {
        item {
            Card2 {
                Title("Akun saya")
                Text("Masuk sebagai ${vm.user} (${ROLE_LABEL[vm.role] ?: vm.role}).")
                if (vm.isWarga) Muted("Data yang tampil dibatasi untuk KK Anda.")
                if (vm.role == "viewer") Muted("Akun Viewer hanya dapat melihat data.")
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.showChangePw = true }) { Text(if (vm.isWarga) "Ganti PIN" else "Ganti password") }
                    OutlinedButton(onClick = { vm.testPush() }) { Text("Tes notifikasi") }
                }
                TextButton(onClick = { logoutAsk = true }) { Text("Keluar", color = RedC) }
            }
        }
        if (vm.isAdmin) item { UserAdminCard(vm, db) }
        if (vm.canEdit) item { SettingsCard(vm, db) }
    }
    if (logoutAsk) Confirm("Keluar dari akun ini?", { logoutAsk = false; vm.logout() }, { logoutAsk = false })
}

@Composable
fun UserAdminCard(vm: AppVm, db: JSONObject) {
    var wid by remember { mutableStateOf("") }
    var uname by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("operator") }
    Card2 {
        Title("Pengguna aplikasi")
        Muted("Buat satu akun untuk setiap kepala keluarga. Login warga: nomor HP terdaftar + PIN 6 angka. PIN/password awal hanya ditampilkan sekali.")
        vm.accounts.forEach { a ->
            val warga = a.optString("role") == "warga"
            Card2(tint = Color(0xFFF4FAF6)) {
                Text(a.optString("nama").ifEmpty { a.optString("username") } + " · " + (ROLE_LABEL[a.optString("role")] ?: ""), fontWeight = FontWeight.Bold)
                Muted((if (warga) "HP: " else "Username: ") + a.optString("username") + " · " + if (a.optBoolean("aktif", true)) "Aktif" else "Nonaktif")
                if (a.optString("username") != vm.user) Row {
                    TextButton(onClick = { vm.toggleAkun(a, !a.optBoolean("aktif", true)) }) { Text(if (a.optBoolean("aktif", true)) "Nonaktifkan" else "Aktifkan") }
                    TextButton(onClick = { if (warga) vm.resetPin(a.optString("username")) else vm.resetPassword(a.optString("username")) }) { Text(if (warga) "Reset PIN" else "Reset password") }
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Text("Buat akun warga", fontWeight = FontWeight.Bold)
        Pick("Kepala keluarga", wid, listOf("" to "— Pilih KK —") + db.list("warga").map { it.str("id") to (it.str("nama") + " · " + it.str("hp").ifEmpty { "tanpa HP" }) }) { wid = it }
        Button(onClick = { vm.buatAkunWarga(wid) }, enabled = wid.isNotEmpty()) { Text("Buat akun warga") }
        Spacer(Modifier.height(10.dp))
        Text("Buat akun pengurus", fontWeight = FontWeight.Bold)
        Field("Username (3–20 karakter)", uname, { uname = it.lowercase() })
        ChipRow(listOf("operator", "viewer"), role) { role = it }
        Button(onClick = { vm.buatAkun(uname, role) }, enabled = uname.length >= 3) { Text("Buat akun") }
    }
}

@Composable
fun SettingsCard(vm: AppVm, db: JSONObject) {
    val s = db.optJSONObject("settings") ?: JSONObject()
    val key = s.toString()
    var rt by remember(key) { mutableStateOf(s.str("rt")) }
    var rw by remember(key) { mutableStateOf(s.str("rw")) }
    var desa by remember(key) { mutableStateOf(s.str("desa")) }
    var kec by remember(key) { mutableStateOf(s.str("kecamatan")) }
    var kota by remember(key) { mutableStateOf(s.str("kota")) }
    var tahun by remember(key) { mutableStateOf(s.optInt("tahun", 2026).toString()) }
    var bend by remember(key) { mutableStateOf(s.str("bendahara")) }
    val saldo = remember(key) { mutableStateMapOf<String, String>().also { m -> Rt.IN_CATS.forEach { k -> m[k] = Rt.saldoKat(db, k).toLong().toString() } } }
    val tarif = remember(key) { mutableStateMapOf<String, String>().also { m -> Rt.DUES_CATS.forEach { k -> m[k] = (s.optJSONObject("tarif")?.num(k) ?: 0.0).toLong().toString() } } }
    Card2 {
        Title("Pengaturan")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { Field("RT", rt, { rt = it }, modifier = Modifier.weight(1f)); Field("RW", rw, { rw = it }, modifier = Modifier.weight(1f)) }
        Field("Desa/Kelurahan", desa, { desa = it }); Field("Kecamatan", kec, { kec = it }); Field("Kabupaten/Kota", kota, { kota = it })
        Field("Tahun buku", tahun, { tahun = it.filter(Char::isDigit).take(4) }, KeyboardType.Number)
        Field("Bendahara", bend, { bend = it })
        Text("Tarif per periode (Rp)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Rt.DUES_CATS.forEach { k -> Field(k, tarif[k] ?: "0", { tarif[k] = it.filter(Char::isDigit) }, KeyboardType.Number) }
        Text("Saldo awal tiap kategori (Rp)", fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Rt.IN_CATS.forEach { k -> Field(k, saldo[k] ?: "0", { saldo[k] = it.filter(Char::isDigit) }, KeyboardType.Number) }
        Spacer(Modifier.height(8.dp))
        Button(onClick = {
            vm.mutate("Pengaturan disimpan.") { d ->
                val st = d.ensureObj("settings")   // field lain (libur/tempat arisan) tetap dipertahankan
                st.put("rt", rt).put("rw", rw).put("desa", desa).put("kecamatan", kec).put("kota", kota)
                    .put("tahun", tahun.toIntOrNull() ?: 2026).put("bendahara", bend)
                val sk = JSONObject(); Rt.IN_CATS.forEach { k -> sk.put(k, saldo[k]?.toLongOrNull() ?: 0L) }
                st.put("saldoKategori", sk).put("saldo", Rt.IN_CATS.sumOf { saldo[it]?.toLongOrNull() ?: 0L })
                val tf = JSONObject(); Rt.DUES_CATS.forEach { k -> tf.put(k, tarif[k]?.toLongOrNull() ?: 0L) }
                st.put("tarif", tf)
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("Simpan pengaturan") }
    }
}
