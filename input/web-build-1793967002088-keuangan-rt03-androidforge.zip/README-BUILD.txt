KEUANGAN RT03 - proyek Android (Gradle) untuk dikompilasi di androidForge

Aplikasi WebView. Halaman utama dimuat dari https://copermine23.github.io/RT03/
(update fitur cukup lewat GitHub, tanpa build APK ulang). Kalau alamat itu gagal
dimuat, aplikasi memakai salinan index.html di app/src/main/assets sebagai cadangan.
Paket: id.rt03.keuangan, minSdk 29 (Android 10+). Versi 1.1.

Build rilis (otomatis ditandatangani dengan app/rt03-release.jks):
    gradle assembleRelease      (butuh JDK 17 + Android SDK 34, Gradle 8.7)
Hasil: app/build/outputs/apk/release/app-release.apk

Kunci penanda tangan: lihat KEYSTORE-INFO.txt (simpan di tempat aman).
APK baru hanya perlu dibuat bila ada perubahan sisi Android (ikon, nama, fitur
cetak/simpan file). Perubahan tampilan/fitur cukup unggah index.html ke GitHub.
Jaga salinan di assets tetap terbaru agar cadangan tidak usang.

NOTIFIKASI PUSH (pengumuman)
Taruh google-services.json dari Firebase di app/google-services.json sebelum build.
Tanpa file itu aplikasi tetap jalan, hanya notifikasi yang nonaktif.
Lihat PANDUAN-NOTIFIKASI.txt. Versi 1.2.
