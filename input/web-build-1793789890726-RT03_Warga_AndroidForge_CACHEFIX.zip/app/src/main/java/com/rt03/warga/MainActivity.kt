package com.rt03.warga

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.messaging.FirebaseMessaging

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var latestFcmToken: String? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNotificationPermission()

        webView = WebView(this)
        setContentView(webView)
        webView.settings.cacheMode = android.webkit.WebSettings.LOAD_NO_CACHE
        webView.clearCache(true)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)
        webView.addJavascriptInterface(NativeBridge(), "RT03Native")
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val host = request?.url?.host ?: return false
                return !(host == "script.google.com" ||
                    host.endsWith(".googleusercontent.com") ||
                    host == "accounts.google.com" ||
                    host.endsWith(".google.com"))
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                latestFcmToken?.let { deliverToken(it) }
                FirebaseMessaging.getInstance().token.addOnSuccessListener {
                    latestFcmToken = it
                    deliverToken(it)
                }
            }
        }
        webView.loadUrl(getString(R.string.web_app_url))
    }

    private fun deliverToken(token: String) {
        val safe = org.json.JSONObject.quote(token)
        runOnUiThread {
            if (::webView.isInitialized) {
                webView.evaluateJavascript(
                    "if (window.onNativeFcmToken) { window.onNativeFcmToken($safe); }",
                    null
                )
            }
        }
    }

    inner class NativeBridge {
        @JavascriptInterface fun appVersion(): String = "1.0.0"
        @JavascriptInterface fun requestFcmToken() {
            FirebaseMessaging.getInstance().token.addOnSuccessListener {
                latestFcmToken = it
                deliverToken(it)
            }
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 301)
        }
    }

    override fun onBackPressed() {
        if (::webView.isInitialized && webView.canGoBack()) webView.goBack()
        else super.onBackPressed()
    }
}
