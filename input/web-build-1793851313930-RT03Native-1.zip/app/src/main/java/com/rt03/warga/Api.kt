package com.rt03.warga

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiException(message: String, val auth: Boolean = false) : Exception(message)

object Api {
    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .readTimeout(90, TimeUnit.SECONDS)
        .build()

    /** Memanggil fungsi Apps Script lewat doPost (Api.gs). Redirect 302 diikuti otomatis. */
    suspend fun call(fn: String, vararg args: Any?): JSONObject = withContext(Dispatchers.IO) {
        val arr = JSONArray()
        args.forEach { arr.put(it ?: JSONObject.NULL) }
        val body = JSONObject().put("fn", fn).put("args", arr).toString()
            .toRequestBody("text/plain;charset=utf-8".toMediaType())
        val req = Request.Builder().url(Config.API_URL).post(body).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw ApiException("Server error ${r.code}")
            val json = try { JSONObject(text) } catch (e: Exception) {
                throw ApiException("Respons server tidak valid. Pastikan URL web app benar dan akses diset 'Anyone'.")
            }
            if (json.has("error")) {
                val m = json.optString("error")
                throw ApiException(m, auth = m.contains("Sesi login"))
            }
            json
        }
    }
}
