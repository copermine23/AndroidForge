RT03 - Aplikasi Keuangan Warga (Android WebView Wrapper)
=======================================================

Package  : com.rt03.keuangan
App Name : RT03
Min SDK  : 24 (Android 7.0)
Target   : 34

Cara pakai di AndroidForge:
1. Zip seluruh isi folder ini (pastikan settings.gradle & build.gradle ada di root zip).
2. Upload ZIP ke AndroidForge.
3. Pilih build variant: debug atau release.
4. Tunggu proses build selesai, lalu unduh APK.

Fitur:
- Splash screen mirip desain web sebelumnya (hijau #087443 + ikon).
- WebView full-screen yang langsung membuka aplikasi Google Apps Script.
- Deteksi koneksi internet + tombol "Coba Lagi" jika gagal.
- Tombol back mengikuti riwayat halaman di WebView.
- JavaScript & DOM Storage aktif (diperlukan untuk Apps Script).

URL yang dibuka:
https://script.google.com/macros/s/AKfycbxp7rtkzEb0ZQ5jQoafERLq4rYYDuh-sQoDWfL9vqCHqA8gpQK00oQOUtS_YfpFKfG6/exec

Catatan:
- Aplikasi memerlukan internet.
- Backend tetap di Google Apps Script (tidak diubah).
