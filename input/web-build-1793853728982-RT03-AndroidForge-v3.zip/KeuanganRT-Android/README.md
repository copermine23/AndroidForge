# RT03 — Android WebView (untuk AndroidForge)

## WAJIB SEBELUM BUILD

1. Buka file:
   `app/src/main/res/values/strings.xml`

2. Ganti baris ini dengan **URL Web App Google Apps Script** yang sudah di-Deploy:
   ```xml
   <string name="web_app_url">https://script.google.com/macros/s/AKfycbxJ-8n0AHdv4rGaqUUXAqWaUvmrg0dWH8f3ki3uhanHJfchsGTVhApkeIKwp_E8LPJA/exec</string>
   ```

3. Di Google Apps Script → Deploy → Manage deployments → pastikan akses **"Anyone"**.

## Cara build di AndroidForge

1. Upload ZIP ini ke https://professional-x.github.io/AndroidForge/
2. Pilih **debug** (disarankan dulu)
3. Build → unduh APK dari artifact GitHub Actions
4. Install APK di HP

## Jika masih gagal install

- Uninstall dulu aplikasi "RT03" yang lama (jika ada)
- Pastikan yang diunduh adalah file `.apk`, bukan `.aab`
- Coba build **debug** (bukan release)
- Matikan sementara Play Protect saat install
- Jika masih error, kirim log build dari AndroidForge

## Package name
`com.rt03.keuangan`
