========================================
 Keuangan RT — paket Android Forge
========================================

ISI PAKET
- index.html              entry point aplikasi
- keuangan-rt.keystore    tanda tangan APK
- keystore.jks            salinan (nama umum)
- release.keystore        salinan (nama umum)

DATA TANDA TANGAN
- Alias          : keuanganrt
- Store password : keuanganrt2026
- Key password   : keuanganrt2026

Jika form build meminta isi manual:
  Keystore file  = keuangan-rt.keystore (atau keystore.jks)
  Alias          = keuanganrt
  Password       = keuanganrt2026

Jika tidak ada opsi custom keystore, unggah
zip ini utuh; beberapa builder otomatis memakai
file *.keystore / *.jks di dalam zip.

Saran build:
- Nama app   : Keuangan RT
- Package    : com.rt.keuangan
- Orientasi  : Portrait
- Izin       : INTERNET (wajib)

PERINGATAN: keystore ini untuk uji coba/internal.
Simpan password; jangan hilangkan file keystore.
