# Keuangan RT — Aplikasi Android (APK)

Aplikasi Android berbasis **WebView** yang memuat web app Google Apps Script Anda:

`https://script.google.com/macros/s/AKfycbz_BN6khcE_n2_NzUQ5a2svSRp2Xsd6BbaEAXCLFLah3eOj8Ti0ytYnCyfa0LpZyWhi/exec`

Karena login, sinkronisasi Google Drive, dan `google.script.run` hanya berjalan di domain Apps Script, APK **tidak** menyimpan HTML offline — ia membuka URL deployment di WebView.

## Fitur wrapper

- JavaScript + DOM storage aktif (wajib untuk aplikasi)
- Cookie / sesi login dipertahankan
- Tombol **Back** Android = navigasi WebView (bukan langsung keluar)
- Link **WhatsApp** (`wa.me`) dibuka di aplikasi WhatsApp
- Tampilan loading & layar offline + tombol Coba lagi
- Nama aplikasi: **Keuangan RT**

## Cara build APK (Android Studio)

### 1. Instal Android Studio
Unduh: https://developer.android.com/studio

### 2. Buka proyek
1. **File → Open** → pilih folder `KeuanganRT`
2. Tunggu Gradle sync selesai (pertama kali bisa 5–15 menit)

### 3. (Opsional) Ikon aplikasi
**File → New → Image Asset** → buat ikon launcher baru agar terlihat bagus di semua perangkat.

### 4. Ubah URL (jika deployment baru)
Edit `app/src/main/res/values/strings.xml` → `web_app_url`.

Pastikan deployment Apps Script:
- **Execute as:** Me (akun pemilik)
- **Who has access:** Anyone (atau sesuai kebutuhan)
- Setelah ubah `index.html` / `Code.gs`, **Deploy → Manage deployments → Edit → New version**

### 5. Build APK debug (uji di HP)
1. Sambungkan HP (USB debugging) atau pakai emulator
2. Klik **Run ▶**
3. Atau: **Build → Build Bundle(s) / APK(s) → Build APK(s)**
4. File: `app/build/outputs/apk/debug/app-debug.apk`

### 6. Build APK release (bagi warga)
1. **Build → Generate Signed App Bundle / APK → APK**
2. Buat keystore baru (simpan password & file `.jks` dengan aman)
3. Pilih **release**
4. File hasil: `app/build/outputs/apk/release/app-release.apk`

Instal di HP: salin APK → buka file → izinkan “Sumber tidak dikenal” jika diminta.

## Catatan penting

| Hal | Penjelasan |
|-----|------------|
| Internet | Wajib online; data di Google Drive |
| Login | Sama seperti di browser (admin / operator / viewer) |
| Unduh CSV/JSON | Bisa terbatas di WebView; jika gagal, buka di Chrome |
| Google login | Jika Google meminta verifikasi akun, WebView biasanya menanganinya |
| Update isi aplikasi | Cukup update & redeploy di Apps Script — **tidak perlu rebuild APK** (kecuali ganti URL) |

## Struktur proyek

```
KeuanganRT/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/rt/keuangan/MainActivity.kt
│       └── res/...
├── build.gradle.kts
├── settings.gradle.kts
└── README.md
```

## Alternatif cepat (tanpa coding)

Jika tidak ingin memakai Android Studio:

1. [WebIntoApp](https://www.webintoapp.com/) / [AppsGeyser](https://appsgeyser.com/) / [PWABuilder](https://www.pwabuilder.com/)
2. Masukkan URL deployment di atas
3. Unduh APK yang dihasilkan

Proyek di folder ini lebih terkontrol (izin, back button, WhatsApp, offline UI).
