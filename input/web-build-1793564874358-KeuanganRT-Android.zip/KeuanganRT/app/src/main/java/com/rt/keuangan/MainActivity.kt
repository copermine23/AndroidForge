package com.rt.keuangan

import android.annotation.SuppressLint
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.DownloadListener
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat

/**
 * WebView wrapper untuk aplikasi Keuangan RT (Google Apps Script).
 * Memuat URL deployment agar google.script.run tetap berfungsi.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var loadingOverlay: LinearLayout
    private lateinit var offlineOverlay: LinearLayout
    private lateinit var offlineMessage: TextView
    private lateinit var btnRetry: Button

    private val appUrl: String by lazy { getString(R.string.web_app_url) }
    private var hasError = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        loadingOverlay = findViewById(R.id.loadingOverlay)
        offlineOverlay = findViewById(R.id.offlineOverlay)
        offlineMessage = findViewById(R.id.offlineMessage)
        btnRetry = findViewById(R.id.btnRetry)

        setupWebView()
        btnRetry.setOnClickListener { reloadApp() }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState)
            hideLoading()
        } else {
            loadApp()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            cacheMode = WebSettings.LOAD_DEFAULT
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            useWideViewPort = true
            loadWithOverviewMode = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            allowFileAccess = false
            allowContentAccess = true
            mediaPlaybackRequiresUserGesture = true
            // User-Agent mirip Chrome agar Apps Script stabil
            userAgentString = userAgentString.replace("; wv", "")
        }

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url?.toString() ?: return false
                return handleExternalUrl(url)
            }

            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleExternalUrl(url)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                hasError = false
                showLoading()
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                if (!hasError) {
                    hideLoading()
                    offlineOverlay.visibility = View.GONE
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                if (request?.isForMainFrame == true) {
                    hasError = true
                    showOffline(error?.description?.toString())
                }
            }
        }

        webView.webChromeClient = WebChromeClient()

        // Unduh file (CSV / JSON backup) lewat browser sistem
        webView.setDownloadListener(DownloadListener { url, _, contentDisposition, mimeType, _ ->
            try {
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    data = Uri.parse(url)
                }
                // Jika blob/data URL, biarkan WebView handle; untuk http buka browser
                if (url.startsWith("http")) {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                } else {
                    val filename = URLUtil.guessFileName(url, contentDisposition, mimeType)
                    Toast.makeText(this, "Unduhan: $filename", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Tidak dapat mengunduh file", Toast.LENGTH_SHORT).show()
            }
        })
    }

    /**
     * WhatsApp (wa.me), mailto, tel, dan domain di luar Apps Script
     * dibuka di aplikasi luar agar tidak merusak sesi di WebView.
     */
    private fun handleExternalUrl(url: String): Boolean {
        val lower = url.lowercase()
        return when {
            lower.startsWith("https://script.google.com") ||
            lower.startsWith("https://accounts.google.com") ||
            lower.startsWith("https://www.google.com") ||
            lower.contains("googleusercontent.com") -> false // biarkan WebView

            lower.startsWith("https://wa.me") ||
            lower.startsWith("whatsapp://") ||
            lower.startsWith("mailto:") ||
            lower.startsWith("tel:") ||
            lower.startsWith("sms:") ||
            lower.startsWith("intent:") -> {
                openExternal(url)
                true
            }

            lower.startsWith("http://") || lower.startsWith("https://") -> {
                // Link eksternal lain (mis. unduhan) buka browser
                openExternal(url)
                true
            }

            else -> false
        }
    }

    private fun openExternal(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan ini", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadApp() {
        hasError = false
        offlineOverlay.visibility = View.GONE
        showLoading()
        webView.loadUrl(appUrl)
    }

    private fun reloadApp() {
        loadApp()
    }

    private fun showLoading() {
        loadingOverlay.visibility = View.VISIBLE
    }

    private fun hideLoading() {
        loadingOverlay.visibility = View.GONE
    }

    private fun showOffline(detail: String?) {
        hideLoading()
        offlineOverlay.visibility = View.VISIBLE
        offlineMessage.text = if (!detail.isNullOrBlank()) {
            getString(R.string.offline_message) + "\n($detail)"
        } else {
            getString(R.string.offline_message)
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    override fun onPause() {
        webView.onPause()
        super.onPause()
    }

    override fun onResume() {
        super.onResume()
        webView.onResume()
    }

    override fun onDestroy() {
        webView.apply {
            loadUrl("about:blank")
            stopLoading()
            clearHistory()
            removeAllViews()
            destroy()
        }
        super.onDestroy()
    }
}
