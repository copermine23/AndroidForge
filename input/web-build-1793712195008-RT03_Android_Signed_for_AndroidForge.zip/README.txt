RT03 - Aplikasi Keuangan Warga (Android WebView Wrapper)
=======================================================

Package  : com.rt03.keuangan
App Name : RT03
Min SDK  : 24 (Android 7.0)
Target   : 34
Version  : 1.0.1 (versionCode 2)

SUDAH DITANDATANGANI DENGAN KEYSTORE RELEASE
Lihat file KEYSTORE-INFO.txt untuk detail password & alias.

Cara pakai di AndroidForge:
1. Upload ZIP ke AndroidForge.
2. Pilih build variant: **release** (disarankan).
3. Tunggu proses build selesai, lalu unduh APK.

Fitur:
- Splash screen mirip desain web sebelumnya (hijau #087443 + ikon).
- WebView full-screen yang langsung membuka aplikasi Google Apps Script.
- Deteksi koneksi internet + tombol "Coba Lagi" jika gagal.
- Tombol back mengikuti riwayat halaman di WebView.
- JavaScript & DOM Storage aktif (diperlukan untuk Apps Script).
- Ditandatangani dengan keystore sendiri (bukan debug).

URL yang dibuka:
https://script.google.com/macros/s/AKfycbxp7rtkzEb0ZQ5jQoafERLq4rYYDuh-sQoDWfL9vqCHqA8gpQK00oQOUtS_YfpFKfG6/exec

Catatan:
- Aplikasi memerlukan internet.
- Backend tetap di Google Apps Script (tidak diubah).
- Simpan keystore dengan aman untuk update aplikasi ke depan.
