# Informasi Keystore & Keamanan Aplikasi RT03

## Kredensial Keystore (untuk signing APK release)
- **File Keystore**: `rt03-release.jks` (dapat diletakkan di folder `app/`)
- **Store Password**: `rt031234`
- **Key Alias**: `rt03key`
- **Key Password**: `rt031234`

## Cara Membuat Keystore Sendiri via Terminal (Opsional):
Jika Anda ingin membuat keystore baru yang unik, jalankan perintah berikut di komputer Anda (membutuhkan Java JDK):
```bash
keytool -genkey -v -keystore rt03-release.jks -keyalg RSA -keysize 2048 -validity 10000 -alias rt03key
```

## Tips agar Aplikasi Aman & Lancar Diinstal di Semua HP Android:
1. **Peringatan Play Protect / Sumber Tidak Dikenal**:
   Karena aplikasi ini diinstal manual (sideloading APK) dan bukan langsung dari Google Play Store, Android atau Google Play Protect mungkin akan menampilkan peringatan "Aplikasi tidak dikenal" (Unknown App / Unverified Developer).
   - **Solusi untuk Pengguna**: Saat peringatan muncul, ketuk **"Detail selengkapnya" (More details)** lalu pilih **"Tetap instal" (Install anyway)**.
2. **Izin Internet**:
   Aplikasi ini hanya meminta izin akses internet (`INTERNET` & `ACCESS_NETWORK_STATE`) sehingga aman dan tidak meminta izin berbahaya lain seperti akses kontak, kamera, atau lokasi GPS yang tidak diperlukan.
