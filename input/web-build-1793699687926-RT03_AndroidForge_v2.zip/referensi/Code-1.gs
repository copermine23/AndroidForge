const DATABASE_FILE_NAME = 'KEUANGAN_RT_DATABASE.json';
const SESSION_SECONDS = 21600; // sesi login maksimal 6 jam
const MAX_GAGAL = 5;           // salah password berturut-turut sebelum dikunci 10 menit
const HASH_ROUNDS = 300;
const MIN_PASSWORD = 10;
const PASSWORD_CHARS = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789';

function doGet() {
  return HtmlService.createHtmlOutputFromFile('index')
    .setTitle('Keuangan RT')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1');
}

// ===================== AKUN & SESI =====================

// Jalankan SEKALI dari editor. Password sementara admin muncul di Log eksekusi.
function setupInitialAdmin() {
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ak = getAkun_();
    if (Object.keys(ak).length) {
      throw new Error('Akun sudah ada. setupInitialAdmin hanya boleh dijalankan satu kali.');
    }
    const pw = randomPassword_(14);
    ak['admin'] = buatAkun_(pw, 'admin', true, 1);
    setAkun_(ak);
    console.log('USERNAME ADMIN: admin');
    console.log('PASSWORD SEMENTARA: ' + pw);
    console.log('Catat password ini, jangan dibagikan. Segera ganti setelah login.');
  } finally { lock.releaseLock(); }
}

function login(username, password) {
  const u = String(username || '').trim().toLowerCase();
  const ak = getAkun_();
  if (!Object.keys(ak).length) {
    return { ok: false, message: 'Akun admin belum disiapkan. Jalankan fungsi setupInitialAdmin di editor Apps Script.' };
  }
  const cache = CacheService.getScriptCache();
  const key = 'F_' + u;
  const gagal = Number(cache.get(key) || 0);
  if (gagal >= MAX_GAGAL) return { ok: false, message: 'Terlalu banyak percobaan gagal. Coba lagi 10 menit lagi.' };
  const a = ak[u];
  if (!a || hash_(a.salt, String(password || '')) !== a.hash) {
    cache.put(key, String(gagal + 1), 600);
    return { ok: false, message: 'Nama pengguna atau password salah.' };
  }
  if (a.aktif === false) return { ok: false, message: 'Akun ini dinonaktifkan. Hubungi admin.' };
  cache.remove(key);
  const token = Utilities.getUuid() + Utilities.getUuid();
  cache.put('S_' + token, JSON.stringify({ u: u, v: a.v || 0 }), SESSION_SECONDS);
  return { ok: true, token: token, user: u, role: a.role, temp: !!a.temp };
}

function logout(token) {
  if (token) CacheService.getScriptCache().remove('S_' + token);
  return { ok: true };
}

// Sesi tidak berlaku bila akun dihapus/dinonaktifkan atau password diganti/direset.
function sesi_(token) {
  if (!token) return null;
  const cache = CacheService.getScriptCache();
  const raw = cache.get('S_' + token);
  if (!raw) return null;
  const s = JSON.parse(raw);
  const a = getAkun_()[s.u];
  if (!a || a.aktif === false || (a.v || 0) !== s.v) return null;
  cache.put('S_' + token, raw, SESSION_SECONDS);
  return { user: s.u, role: a.role, temp: !!a.temp };
}

function wajibLogin_(token) {
  const s = sesi_(token);
  if (!s) throw new Error('Sesi login berakhir. Silakan masuk lagi.');
  return s;
}

function wajibAdmin_(token) {
  const s = wajibLogin_(token);
  if (s.role !== 'admin') throw new Error('Hanya admin yang boleh melakukan ini.');
  return s;
}

function daftarAkun(token) {
  wajibAdmin_(token);
  const ak = getAkun_();
  return { ok: true, akun: Object.keys(ak).sort().map(u => ({
    username: u, role: ak[u].role, aktif: ak[u].aktif !== false })) };
}

// Admin membuat akun Operator/Viewer. Password sementara dibuat otomatis, tampil sekali.
function buatAkun(token, data) {
  wajibAdmin_(token);
  const u = String((data && data.username) || '').trim().toLowerCase();
  const role = data && data.role;
  if (!/^[a-z0-9._-]{3,20}$/.test(u)) {
    throw new Error('Nama pengguna 3-20 karakter: huruf, angka, titik, garis bawah, atau strip.');
  }
  if (['operator', 'viewer'].indexOf(role) < 0) throw new Error('Peran harus Operator atau Viewer.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ak = getAkun_();
    if (ak[u]) throw new Error('Nama pengguna sudah dipakai.');
    const pw = randomPassword_(12);
    ak[u] = buatAkun_(pw, role, true, 1);
    setAkun_(ak);
    return { ok: true, username: u, password: pw };
  } finally { lock.releaseLock(); }
}

function ubahStatusAkun(token, username, aktif) {
  const s = wajibAdmin_(token);
  const u = String(username || '').toLowerCase();
  if (u === s.user) throw new Error('Anda tidak bisa menonaktifkan akun sendiri.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ak = getAkun_();
    if (!ak[u]) throw new Error('Akun tidak ditemukan.');
    ak[u].aktif = !!aktif;
    ak[u].v = (ak[u].v || 0) + 1;
    setAkun_(ak);
  } finally { lock.releaseLock(); }
  return { ok: true };
}

function resetPasswordAkun(token, username) {
  const s = wajibAdmin_(token);
  const u = String(username || '').toLowerCase();
  if (u === s.user) throw new Error('Gunakan "Ganti password saya" untuk akun sendiri.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ak = getAkun_();
    if (!ak[u]) throw new Error('Akun tidak ditemukan.');
    const pw = randomPassword_(12);
    ak[u] = buatAkun_(pw, ak[u].role, true, (ak[u].v || 0) + 1, ak[u].aktif !== false);
    setAkun_(ak);
    return { ok: true, password: pw };
  } finally { lock.releaseLock(); }
}

function gantiPassword(token, lama, baru) {
  const s = wajibLogin_(token);
  baru = String(baru || '');
  if (baru.length < MIN_PASSWORD) throw new Error('Password baru minimal ' + MIN_PASSWORD + ' karakter.');
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    const ak = getAkun_();
    const a = ak[s.user];
    if (!a || hash_(a.salt, String(lama || '')) !== a.hash) throw new Error('Password lama salah.');
    if (baru === String(lama)) throw new Error('Password baru harus berbeda dari password lama.');
    // Untuk akun Viewer, satu kali perubahan password berlaku seumur akun.
    // Kompatibilitas: akun lama dengan temp=false dianggap sudah pernah mengganti password.
    if (a.role === 'viewer' && (a.viewerPasswordChanged === true ||
        (a.viewerPasswordChanged === undefined && a.temp === false))) {
      throw new Error('Viewer hanya dapat mengganti password satu kali. Jika lupa, hubungi admin untuk reset password.');
    }
    const updated = buatAkun_(baru, a.role, false, (a.v || 0) + 1, a.aktif !== false);
    updated.viewerPasswordChanged = a.role === 'viewer' ? true : !!a.viewerPasswordChanged;
    ak[s.user] = updated;
    setAkun_(ak);   // menaikkan versi akun -> semua sesi lama otomatis berakhir
  } finally { lock.releaseLock(); }
  return { ok: true };
}

function getAkun_() {
  const raw = PropertiesService.getScriptProperties().getProperty('AKUN');
  return raw ? JSON.parse(raw) : {};
}
function setAkun_(ak) {
  PropertiesService.getScriptProperties().setProperty('AKUN', JSON.stringify(ak));
}
// Password disimpan sebagai hash SHA-256 + salt, bukan teks asli.
function buatAkun_(pw, role, temp, v, aktif) {
  const salt = Utilities.getUuid();
  return { salt: salt, hash: hash_(salt, pw), role: role, temp: !!temp, viewerPasswordChanged: false, v: v || 1, aktif: aktif !== false };
}
function hash_(salt, pw) {
  let h = salt + ':' + pw;
  for (let i = 0; i < HASH_ROUNDS; i++) {
    h = Utilities.base64Encode(Utilities.computeDigest(
      Utilities.DigestAlgorithm.SHA_256, h + salt, Utilities.Charset.UTF_8));
  }
  return h;
}
function randomPassword_(n) {
  const bytes = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,
    Utilities.getUuid() + Utilities.getUuid() + new Date().getTime(), Utilities.Charset.UTF_8);
  let out = '';
  for (let i = 0; i < n; i++) out += PASSWORD_CHARS.charAt((bytes[i] & 255) % PASSWORD_CHARS.length);
  return out;
}

// ===================== DATABASE =====================
function getDatabase(token) {
  const session = sesi_(token);
  if (!session) return { ok: false, auth: true, setupDone: Object.keys(getAkun_()).length > 0 };

  const file = findDatabaseFile_();
  if (!file) {
    const initial = {
      revision: 0,
      db: {
        settings: {
          rt: 'RT 001', rw: 'RW 001',
          desa: 'Isi nama desa/kelurahan',
          kecamatan: 'Isi nama kecamatan',
          kota: 'Isi nama kabupaten/kota',
          tahun: 2026, saldo: 0, bendahara: ''
        },
        warga: [], transaksi: []
      }
    };
    const created = DriveApp.createFile(DATABASE_FILE_NAME, JSON.stringify(initial, null, 2), MimeType.PLAIN_TEXT);
    return { ok: true, db: initial.db, revision: initial.revision, fileId: created.getId(), session: session };
  }
  const stored = parseDatabase_(file);
  return { ok: true, db: stored.db, revision: stored.revision, fileId: file.getId(), session: session };
}

function saveDatabase(payload) {
  if (!payload || !payload.db || !Array.isArray(payload.db.warga) ||
      !Array.isArray(payload.db.transaksi) || !payload.db.settings) {
    throw new Error('Format database tidak valid.');
  }
  const s = sesi_(payload.token);
  if (!s) return { ok: false, auth: true };
  if (s.role !== 'admin' && s.role !== 'operator') {
    return { ok: false, forbidden: true, message: 'Akun Viewer hanya dapat melihat data.' };
  }

  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    let file = findDatabaseFile_();
    let current = file ? parseDatabase_(file) : { revision: 0, db: null };
    const clientRevision = Number(payload.revision || 0);

    // Konflik revisi: mencegah penyimpanan lama menimpa data baru.
    if (clientRevision !== current.revision) {
      return { ok: false, conflict: true, revision: current.revision };
    }

    const next = { revision: current.revision + 1, db: payload.db };
    const content = JSON.stringify(next, null, 2);
    if (file) {
      file.setContent(content);
    } else {
      file = DriveApp.createFile(DATABASE_FILE_NAME, content, MimeType.PLAIN_TEXT);
    }
    return { ok: true, revision: next.revision };
  } finally {
    lock.releaseLock();
  }
}

function findDatabaseFile_() {
  const files = DriveApp.getFilesByName(DATABASE_FILE_NAME);
  return files.hasNext() ? files.next() : null;
}

function parseDatabase_(file) {
  let parsed;
  try {
    parsed = JSON.parse(file.getBlob().getDataAsString('UTF-8'));
  } catch (e) {
    throw new Error('File database di Google Drive rusak atau bukan JSON yang valid.');
  }
  if (!parsed || !parsed.db || !parsed.db.settings ||
      !Array.isArray(parsed.db.warga) || !Array.isArray(parsed.db.transaksi)) {
    throw new Error('Struktur database Google Drive tidak valid.');
  }
  return { revision: Number(parsed.revision || 0), db: parsed.db };
}
