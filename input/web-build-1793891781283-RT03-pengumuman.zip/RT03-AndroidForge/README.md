# Keuangan RT — Android WebView APK (siap AndroidForge)

Proyek Android minimal yang membungkus aplikasi web **Keuangan RT** (Google Apps Script) di dalam WebView.

Versi ini menyertakan dukungan untuk fitur **Pengumuman RT** (update dari paket RT03-Pengumuman-Update).

## Cara pakai di AndroidForge

1. **Ganti URL Apps Script**  
   Buka file:
   ```
   app/src/main/java/com/rt03/keuanganrt/MainActivity.kt
   ```
   Cari baris:
   ```kotlin
   private val APP_URL = "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec"
   ```
   Ganti dengan URL **Deploy → Web app** dari proyek Google Apps Script RT03 Anda (yang sudah di-update dengan index.html Pengumuman).

2. Zip seluruh folder proyek ini (pastikan struktur root berisi `app/`, `build.gradle.kts`, `settings.gradle.kts`, `gradlew`, dll).

3. Upload ZIP ke [AndroidForge](https://professional-x.github.io/AndroidForge/)  
   - Pilih build **debug** atau **release**.
   - Unduh APK hasil build.

## Catatan penting dari PETUNJUK-ID

- Fitur Pengumuman hanya mengubah **index.html** di Apps Script.
- Karena APK hanya WebView yang membuka URL Apps Script, **biasanya tidak perlu rebuild APK** setiap kali update halaman web.
- Rebuild APK hanya diperlukan jika Anda ingin mengubah:
  - Package name / applicationId
  - Nama aplikasi
  - Icon
  - Version code/name
  - Atau URL deployment berubah

## Langkah update Apps Script (wajib sebelum pakai APK)

1. Backup database RT03 (file JSON di Google Drive).
2. Di editor Apps Script, buka file HTML bernama `index`.
3. Ganti seluruh isi dengan isi dari `Apps-Script/index.html` paket update.
4. Code.gs **tidak perlu diganti** untuk fitur pengumuman.
5. Deploy → Manage deployments → Edit → New version → Deploy.
6. Salin URL `/exec` yang baru (atau yang sudah ada) ke `APP_URL` di MainActivity.kt.

## Build lokal (opsional)

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

## Package info

| Item | Nilai |
|------|-------|
| Application ID | `com.rt03.keuanganrt` |
| Min SDK | 24 (Android 7.0) |
| Target SDK | 35 |
| Version | 1.1.0-pengumuman (versionCode 2) |
| Nama aplikasi | Keuangan RT |

## Fitur WebView

- JavaScript + DOM Storage aktif
- Progress bar saat loading
- Tombol Back mengikuti history WebView
- Support rotasi layar
- Error page sederhana jika gagal load
- Cleartext traffic diizinkan (untuk kompatibilitas)

---
Dibuat untuk RT03 – Update Pengumuman RT
