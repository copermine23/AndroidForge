package com.rt03.warga

import android.app.Application
import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

class AppVm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("rt03", Context.MODE_PRIVATE)

    var token by mutableStateOf(prefs.getString("token", "") ?: "")
    var user by mutableStateOf(prefs.getString("user", "") ?: "")
    var role by mutableStateOf(prefs.getString("role", "") ?: "")
    var temp by mutableStateOf(prefs.getBoolean("temp", false))
    var db by mutableStateOf<JSONObject?>(null)
    var status by mutableStateOf("Menghubungkan…")
    var busy by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var secret by mutableStateOf<Pair<String, String>?>(null)
    var accounts by mutableStateOf<List<JSONObject>>(emptyList())
    var showChangePw by mutableStateOf(false)

    private var revision = 0
    private val saveLock = Mutex()
    private var regPair = ""

    val loggedIn get() = token.isNotEmpty()
    val canEdit get() = role == "admin" || role == "operator"
    val isAdmin get() = role == "admin"
    val isWarga get() = role == "warga"

    private fun setAuth(t: String, u: String, r: String, tmp: Boolean) {
        token = t; user = u; role = r; temp = tmp
        prefs.edit().putString("token", t).putString("user", u).putString("role", r).putBoolean("temp", tmp).apply()
    }

    fun login(username: String, password: String) {
        viewModelScope.launch {
            busy = true
            try {
                val r = Api.call("login", username, password)
                if (r.optBoolean("ok")) {
                    db = null
                    setAuth(r.optString("token"), r.optString("user"), r.optString("role"), r.optBoolean("temp"))
                    load()
                    if (r.optBoolean("temp")) showChangePw = true
                } else message = r.optString("message", "Gagal masuk.")
            } catch (e: Exception) {
                message = e.message ?: "Gagal terhubung ke server."
            } finally { busy = false }
        }
    }

    fun logout(local: Boolean = false, msg: String? = null) {
        val t = token
        if (!local && t.isNotEmpty()) viewModelScope.launch { runCatching { Api.call("logout", t) } }
        setAuth("", "", "", false)
        db = null; accounts = emptyList(); revision = 0; regPair = ""
        status = "Silakan masuk"
        if (msg != null) message = msg
    }

    fun load() {
        if (token.isEmpty() || saveLock.isLocked) return
        viewModelScope.launch {
            try {
                val r = Api.call("getDatabase", token)
                if (r.optBoolean("auth")) { logout(true, "Sesi login berakhir. Silakan masuk lagi."); return@launch }
                if (r.optBoolean("ok")) {
                    val s = r.optJSONObject("session")
                    if (s != null && (s.optString("role") != role || s.optString("user") != user || s.optBoolean("temp") != temp))
                        setAuth(token, s.optString("user"), s.optString("role"), s.optBoolean("temp"))
                    val rev = r.optInt("revision")
                    if (db == null || rev != revision) { db = r.getJSONObject("db"); revision = rev }
                    status = "Tersinkron ke Google Drive"
                    registerFcm()
                }
            } catch (e: ApiException) {
                if (e.auth) logout(true, e.message) else status = e.message ?: "Gagal memuat"
            } catch (e: Exception) { status = "Tidak terhubung — periksa koneksi" }
        }
    }

    /** Ubah salinan DB, tampilkan langsung, lalu simpan ke server dengan nomor revision. */
    fun mutate(okMsg: String? = null, block: (JSONObject) -> Unit) {
        val cur = db ?: return
        if (!canEdit) { message = "Akun ini hanya dapat melihat data."; return }
        val copy = JSONObject(cur.toString())
        block(copy)
        db = copy
        viewModelScope.launch {
            saveLock.withLock {
                try {
                    status = "Menyimpan…"
                    val payload = JSONObject().put("db", copy).put("revision", revision).put("token", token)
                    val r = Api.call("saveDatabase", payload)
                    when {
                        r.optBoolean("ok") -> { revision = r.optInt("revision"); status = "Tersinkron ke Google Drive"; if (okMsg != null) message = okMsg }
                        r.optBoolean("auth") -> logout(true, "Sesi login berakhir. Perubahan terakhir belum tersimpan.")
                        r.optBoolean("forbidden") -> { message = r.optString("message", "Tidak berhak mengubah data."); reload() }
                        else -> { message = "Perubahan belum tersimpan karena data sudah diubah dari perangkat lain. Data terbaru dimuat, silakan ulangi."; reload() }
                    }
                } catch (e: ApiException) {
                    if (e.auth) logout(true, e.message) else { message = e.message; reload() }
                } catch (e: Exception) {
                    message = "Gagal menyimpan. Periksa koneksi internet."; reload()
                }
            }
        }
    }

    private suspend fun reload() {
        try {
            val r = Api.call("getDatabase", token)
            if (r.optBoolean("ok")) { db = r.getJSONObject("db"); revision = r.optInt("revision") }
        } catch (_: Exception) {}
    }

    private fun registerFcm() {
        if (token.isEmpty()) return
        runCatching {
            FirebaseMessaging.getInstance().token.addOnSuccessListener { t ->
                val pair = "$token|$t"
                if (pair == regPair) return@addOnSuccessListener
                regPair = pair
                viewModelScope.launch { try { Api.call("registerFcmToken", token, t) } catch (_: Exception) { regPair = "" } }
            }
        }
    }

    fun srv(fn: String, vararg args: Any?, onOk: (JSONObject) -> Unit) {
        viewModelScope.launch {
            busy = true
            try { onOk(Api.call(fn, *args)) }
            catch (e: ApiException) { if (e.auth) logout(true, e.message) else message = e.message }
            catch (e: Exception) { message = "Gagal terhubung ke server." }
            finally { busy = false }
        }
    }

    fun loadAccounts() = srv("daftarAkun", token) { r -> accounts = r.optJSONArray("akun")?.items() ?: emptyList() }

    fun buatAkunWarga(wargaId: String) = srv("buatAkunWarga", token, wargaId) { r ->
        secret = "PIN awal warga" to "HP: ${r.optString("username")}\nPIN: ${r.optString("pin")}"; loadAccounts()
    }
    fun buatAkun(username: String, role: String) = srv("buatAkun", token, JSONObject().put("username", username).put("role", role)) { r ->
        secret = "Password sementara" to "Username: ${r.optString("username")}\nPassword: ${r.optString("password")}"; loadAccounts()
    }
    fun resetPin(hp: String) = srv("resetPinWarga", token, hp) { r -> secret = "PIN baru warga" to "HP: $hp\nPIN: ${r.optString("pin")}" }
    fun resetPassword(username: String) = srv("resetPasswordAkun", token, username) { r ->
        secret = "Password sementara" to "Username: $username\nPassword: ${r.optString("password")}"
    }
    fun toggleAkun(a: JSONObject, aktif: Boolean) {
        val key = if (a.optString("role") == "warga") "warga_" + a.optString("username") else a.optString("username")
        srv("ubahStatusAkun", token, key, aktif) { loadAccounts() }
    }
    fun gantiPassword(lama: String, baru: String) {
        val fn = if (isWarga) "gantiPin" else "gantiPassword"
        srv(fn, token, lama, baru) {
            showChangePw = false
            logout(true, (if (isWarga) "PIN" else "Password") + " berhasil diganti. Silakan masuk kembali.")
        }
    }
    fun testPush() = srv("testPushNotification", token) { message = "Notifikasi percobaan terkirim. Periksa layar HP." }
}
