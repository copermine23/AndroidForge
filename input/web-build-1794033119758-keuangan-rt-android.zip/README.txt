Keuangan RT — proyek Android (WebView) untuk AndroidForge
Package: com.rt.keuangan
Keystore: keuangan-rt.keystore
  alias=keuanganrt
  password=keuanganrt2026
