package com.rt03.warga

import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

/** Logika bisnis — port dari index.html. DB tetap JSONObject agar field yang tidak dikenal ikut tersimpan. */
fun JSONArray.items(): List<JSONObject> = (0 until length()).mapNotNull { optJSONObject(it) }
fun JSONObject.list(k: String): List<JSONObject> = (optJSONArray(k) ?: JSONArray()).items()
fun JSONObject.ensureArr(k: String): JSONArray = optJSONArray(k) ?: JSONArray().also { put(k, it) }
fun JSONObject.ensureObj(k: String): JSONObject = optJSONObject(k) ?: JSONObject().also { put(k, it) }
fun JSONObject.str(k: String): String = if (isNull(k)) "" else optString(k, "")
fun JSONObject.num(k: String): Double = optDouble(k, 0.0).let { if (it.isNaN()) 0.0 else it }
fun JSONArray.removeWhere(pred: (JSONObject) -> Boolean) {
    for (i in length() - 1 downTo 0) { val o = optJSONObject(i); if (o != null && pred(o)) remove(i) }
}

data class Due(val warga: JSONObject, val tagihan: Double, val paid: Double, val left: Double, val tglLunas: String)
data class CatBalance(val kategori: String, val awal: Double, val masuk: Double, val keluar: Double) {
    val saldo get() = awal + masuk - keluar
}

object Rt {
    val IN_CATS = listOf("Iuran Warga", "Jimpitan Jaga", "Arisan Ngaji", "Dana Sosial", "Kas Musholla", "Sumbangan", "Bantuan Pemerintah", "Hasil Kegiatan", "Lain-lain")
    val DUES_CATS = listOf("Iuran Warga", "Jimpitan Jaga", "Arisan Ngaji", "Dana Sosial", "Kas Musholla")
    val OUT_CATS = listOf("Kebersihan", "Keamanan", "Listrik/Air", "Perbaikan Lingkungan", "Kegiatan Sosial", "Administrasi", "Kas Musholla", "Lain-lain")
    val METHODS = listOf("Tunai", "Transfer", "QRIS", "Lainnya")

    fun rup(n: Double): String =
        NumberFormat.getCurrencyInstance(Locale("id", "ID")).apply { maximumFractionDigits = 0 }.format(n)

    fun dateNow(): String {
        val c = Calendar.getInstance()
        return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }
    fun monthNow() = dateNow().take(7)
    fun paruhNow() = if (dateNow().substring(8, 10).toInt() <= 15) 1 else 2
    fun periodNow(k: String) = if (k == "Arisan Ngaji") "${monthNow()}-${paruhNow()}" else monthNow()
    fun newId(prefix: String) =
        prefix + "-" + System.currentTimeMillis().toString(36).uppercase() + (1..3).map { "ABCDEFGHJKLMNPQRSTUVWXYZ23456789".random() }.joinToString("")

    fun income(db: JSONObject) = db.list("transaksi").filter { it.str("jenis") == "Pemasukan" }.sumOf { it.num("nominal") }
    fun expense(db: JSONObject) = db.list("transaksi").filter { it.str("jenis") == "Pengeluaran" }.sumOf { it.num("nominal") }
    fun saldoAwal(db: JSONObject) = db.optJSONObject("settings")?.num("saldo") ?: 0.0
    fun saldoKas(db: JSONObject) = saldoAwal(db) + income(db) - expense(db)

    fun monthTotals(db: JSONObject, m: String): Pair<Double, Double> {
        val a = db.list("transaksi").filter { it.str("tanggal").startsWith(m) }
        return a.filter { it.str("jenis") == "Pemasukan" }.sumOf { it.num("nominal") } to
            a.filter { it.str("jenis") == "Pengeluaran" }.sumOf { it.num("nominal") }
    }
    fun saldoAwalBulan(db: JSONObject, m: String): Double {
        val before = db.list("transaksi").filter { it.str("tanggal") < "$m-01" }
        return saldoAwal(db) + before.filter { it.str("jenis") == "Pemasukan" }.sumOf { it.num("nominal") } -
            before.filter { it.str("jenis") == "Pengeluaran" }.sumOf { it.num("nominal") }
    }

    fun activeWarga(db: JSONObject) = db.list("warga").filter { it.str("status") != "Nonaktif" }

    fun tarif(db: JSONObject, w: JSONObject, k: String): Double {
        val t = db.optJSONObject("settings")?.optJSONObject("tarif")?.num(k) ?: 0.0
        return if (t > 0) t else if (k == "Iuran Warga") w.num("iuran") else 0.0
    }
    fun saldoKat(db: JSONObject, k: String): Double {
        val s = db.optJSONObject("settings")
        val sk = s?.optJSONObject("saldoKategori")
        return if (sk != null) sk.num(k) else if (k == "Lain-lain") (s?.num("saldo") ?: 0.0) else 0.0
    }
    fun isLibur(db: JSONObject, k: String, p: String): Boolean {
        if (k != "Arisan Ngaji") return false
        val arr = db.optJSONObject("settings")?.optJSONArray("liburArisan") ?: return false
        return (0 until arr.length()).any { arr.optString(it) == p }
    }
    fun periodOf(t: JSONObject): String {
        if (t.str("kategori") == "Arisan Ngaji") {
            val p = t.str("periode")
            if (Regex("^\\d{4}-\\d{2}-[12]$").matches(p)) return p
            val tg = t.str("tanggal")
            if (tg.length >= 10) return tg.take(7) + "-" + (if (tg.substring(8, 10).toInt() <= 15) 1 else 2)
        }
        return t.str("periode")
    }
    fun periodLabel(k: String, p: String) =
        if (k == "Arisan Ngaji") p.take(7) + (if (p.endsWith("-1")) " · tgl 1–15" else " · tgl 16–akhir") else p

    fun duesOf(db: JSONObject, k: String, p: String): List<Due> {
        if (isLibur(db, k, p)) return emptyList()
        val m = p.take(7)
        val tx = db.list("transaksi")
        return activeWarga(db).filter { it.str("tanggal").isEmpty() || it.str("tanggal").take(7) <= m }.mapNotNull { w ->
            val tg = tarif(db, w, k)
            if (tg <= 0) return@mapNotNull null
            val pays = tx.filter {
                it.str("jenis") == "Pemasukan" && it.str("kategori") == k && it.str("wargaId") == w.str("id") && periodOf(it) == p
            }.sortedBy { it.str("tanggal") }
            val paid = pays.sumOf { it.num("nominal") }
            var tl = ""
            if (paid >= tg) { var run = 0.0; for (t in pays) { run += t.num("nominal"); if (run >= tg) { tl = t.str("tanggal"); break } } }
            Due(w, tg, paid, maxOf(0.0, tg - paid), tl)
        }
    }

    fun categoryBalances(db: JSONObject, year: String): List<CatBalance> {
        val rows = db.list("transaksi").filter { it.str("tanggal").startsWith(year) }
        return IN_CATS.map { k ->
            CatBalance(
                k, saldoKat(db, k),
                rows.filter { it.str("jenis") == "Pemasukan" && it.str("kategori") == k }.sumOf { it.num("nominal") },
                rows.filter { it.str("jenis") == "Pengeluaran" && it.str("sumberDana") == k }.sumOf { it.num("nominal") }
            )
        }
    }

    fun newDb(): JSONObject = JSONObject(
        """{"settings":{"rt":"RT 001","rw":"RW 001","desa":"","kecamatan":"","kota":"","tahun":${Calendar.getInstance().get(Calendar.YEAR)},"saldo":0,"bendahara":""},"warga":[],"transaksi":[],"pengumuman":[]}"""
    )
}
