SUNNOER BADMINTON ARENA - PROJECT ANDROID

Isi
- Aplikasi HTML asli disimpan sebagai app/src/main/assets/index.html.
- Android WebView membungkus aplikasi tersebut agar bisa dipasang sebagai aplikasi Android.
- JavaScript dan DOM Storage diaktifkan agar fitur aplikasi dan localStorage berjalan.
- Izin INTERNET disertakan untuk Tailwind CDN dan sinkronisasi Google Apps Script.

CARA MEMBUAT APK (memerlukan komputer/laptop)
1. Pasang Android Studio versi terbaru.
2. Ekstrak folder SunnoerBadmintonAndroid.
3. Buka Android Studio > Open > pilih folder SunnoerBadmintonAndroid.
4. Tunggu Gradle Sync selesai. Jika diminta, pasang Android SDK Platform 35 dan Build Tools.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug akan dibuat di app/build/outputs/apk/debug/app-debug.apk.
7. Kirim APK ke HP Android, buka file APK, lalu izinkan pemasangan dari sumber tersebut jika diminta.

CATATAN PENTING
- Lingkungan pembuatan ini tidak memiliki Android SDK/Gradle, jadi file APK belum dapat dikompilasi di sini. Ini adalah proyek Android Studio yang siap dibuka dan dibangun menjadi APK.
- Aplikasi masih memuat Tailwind dari CDN; koneksi internet diperlukan untuk tampilan bergaya penuh.
- Data lokal tersimpan di penyimpanan aplikasi pada perangkat. Agar data booking bisa dipakai bersama lintas perangkat, hubungkan endpoint Google Apps Script/Google Sheets dari menu pengaturan aplikasi.
- Sebelum digunakan sungguhan, ganti kredensial admin bawaan melalui menu pengaturan. Jangan membagikan akses admin kepada pelanggan.
- Uji alur booking, kasir, dan sinkronisasi Google Sheets setelah APK dibuat.
