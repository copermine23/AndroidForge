# RT03 - APK WebView

Aplikasi Android WebView untuk **RT03** (Google Apps Script - Keuangan RT).

## Cara Build di AndroidForge / Android Studio

### AndroidForge
1. Upload file ZIP ini
2. Build APK (Debug atau Release)
3. Unduh hasilnya

### Android Studio
1. Extract ZIP
2. Buka folder `KeuanganRT` di Android Studio
3. Sync Gradle
4. Build → Build Bundle(s) / APK(s) → Build APK(s)

## Fitur
- Full WebView ke aplikasi GAS
- JavaScript + DOM Storage aktif (wajib untuk login & sinkron)
- Cookie & session tersimpan
- Pull-to-refresh
- Tombol Back mengikuti history WebView
- Progress bar loading
- Status bar hijau sesuai tema aplikasi

## URL yang diload
```
https://script.google.com/macros/s/AKfycbxaXQ09jhCaaA1CVjqOgoe2NjFK11dfZjltPBJYv1UJvDF20Bx2AHOHWA6fkZnOiI24/exec
```

## Package
`com.rt.keuangan`

## Nama aplikasi (di HP)
**RT03**

## Catatan
- Butuh koneksi internet
- Login & data tetap dari Google Apps Script + Google Drive
- Tidak menyimpan data lokal di HP
