# Keuangan RT - AndroidForge source project

Project Android native sederhana (Kotlin + WebView) untuk membuka aplikasi Keuangan RT dari Google Apps Script.

## Build
Unggah ZIP ini ke AndroidForge. Pilih target Android dan build variant `debug` atau `auto`.

## Catatan penting
- Aplikasi memuat URL Google Apps Script yang sudah dipublikasikan; internet wajib tersedia.
- Data dan backend tetap berada di Google Apps Script/Google Drive, bukan disimpan di APK.
- WebView mengaktifkan JavaScript, DOM Storage, dan cookies agar fitur web dapat berjalan.
- Setelah APK terpasang, uji login, tambah/simpan transaksi, buka laporan, serta akun Viewer sebelum membagikan APK.
- Jika `google.script.run` atau login Google tidak berjalan di WebView AndroidForge, gunakan opsi build berbasis URL/Chrome Custom Tab atau ubah aplikasi menjadi backend API terpisah. ZIP ini belum membuktikan kompatibilitas runtime Google Apps Script.

Package: id.rt.keuangan
App name: Keuangan RT
Version: 1.0
