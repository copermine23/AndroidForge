# Warga RT03 — versi native (Kotlin + Jetpack Compose)

Pengganti APK WebView. Tidak ada WebView; semua layar adalah UI native.
Backend tetap Apps Script + database JSON di Google Drive yang sama.

## 1. Backend (sekali saja)
1. Buka proyek Apps Script, tambah file baru `Api.gs`, isi dengan `backend/Api.gs`. `Code.gs` tidak diubah.
2. Deploy > Manage deployments > Edit > Version: New version
   (Execute as: **Me**, Who has access: **Anyone**). Autentikasi tetap lewat token login aplikasi.
3. Salin URL yang berakhiran `/exec`.

## 2. Aplikasi
1. Tempel URL ke `app/src/main/java/com/rt03/warga/Config.kt` (`API_URL`).
2. Letakkan `google-services.json` dari proyek Firebase lama (`rt03-29902`, package `com.rt03.warga`) di folder `app/`.
3. Build di AndroidForge / Android Studio (AGP 8.5.2, Kotlin 1.9.24, minSdk 26).

## Isi aplikasi
- Login pengurus (username/password) dan warga (HP + PIN 6 angka); ganti password/PIN; sesi 6 jam dari server.
- Beranda (saldo, pengumuman, saldo per kategori), Warga, Transaksi, Iuran (+ libur arisan), Laporan bulanan, Lainnya (akun, pengguna, pengaturan).
- Sinkron dengan nomor `revision` (anti-bentrok) dan penyegaran otomatis tiap 30 detik.
- Push FCM: token didaftarkan lewat `registerFcmToken`; notifikasi pembayaran/pengumuman/tes tetap bekerja.
- Field database yang belum dikenal aplikasi tetap dipertahankan saat menyimpan.

## Belum dipindahkan dari versi web
Kuitansi, ekspor CSV, backup/restore JSON, pengaturan tempat arisan, dan detail pengeluaran per kategori. Semua itu bisa ditambahkan.
