package com.rt03.warga;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class RT03MessagingService extends FirebaseMessagingService {
    private static final String CHANNEL_ID = "rt03_warga_notifications";

    @Override public void onNewToken(String token) {
        super.onNewToken(token);
        getSharedPreferences("rt03", MODE_PRIVATE).edit().putString("fcm_token", token).apply();
        Intent intent = new Intent("com.rt03.warga.NEW_FCM_TOKEN");
        intent.putExtra("token", token);
        sendBroadcast(intent);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        super.onMessageReceived(message);
        String title = message.getNotification() != null && message.getNotification().getTitle() != null ? message.getNotification().getTitle() : message.getData().get("title");
        String body = message.getNotification() != null && message.getNotification().getBody() != null ? message.getNotification().getBody() : message.getData().get("body");
        if (title == null) title = "Informasi RT03";
        if (body == null) body = "Ada informasi baru dari RT03.";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && nm != null) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Notifikasi RT03", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(channel);
        }
        Intent open = new Intent(this, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title).setContentText(body).setStyle(new NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        if (nm != null) nm.notify((int)System.currentTimeMillis(), b.build());
    }
}
