package id.rt03.keuangan;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

/** Menerima notifikasi pengumuman dari Firebase dan menyimpan token HP. */
public class PushService extends FirebaseMessagingService {

    static final String CHANNEL_ID = "pengumuman";

    static void ensureChannel(Context c) {
        NotificationManager nm = c.getSystemService(NotificationManager.class);
        if (nm != null && nm.getNotificationChannel(CHANNEL_ID) == null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "Pengumuman RT", NotificationManager.IMPORTANCE_HIGH);
            nm.createNotificationChannel(ch);
        }
    }

    static void simpanToken(Context c, String token) {
        c.getSharedPreferences("push", Context.MODE_PRIVATE).edit().putString("token", token).apply();
    }

    static String ambilToken(Context c) {
        return c.getSharedPreferences("push", Context.MODE_PRIVATE).getString("token", "");
    }

    @Override
    public void onNewToken(String token) {
        simpanToken(this, token);
    }

    // Dipanggil saat aplikasi sedang terbuka; di latar belakang notifikasi ditampilkan sistem.
    @Override
    public void onMessageReceived(RemoteMessage message) {
        RemoteMessage.Notification n = message.getNotification();
        String title = n != null && n.getTitle() != null ? n.getTitle() : message.getData().get("title");
        String body = n != null && n.getBody() != null ? n.getBody() : message.getData().get("body");
        if (title == null) title = "Pengumuman";
        if (body == null) body = "";

        ensureChannel(this);
        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification notif = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notif)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new Notification.BigTextStyle().bigText(body))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .build();
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) nm.notify((int) (System.currentTimeMillis() % Integer.MAX_VALUE), notif);
    }
}
