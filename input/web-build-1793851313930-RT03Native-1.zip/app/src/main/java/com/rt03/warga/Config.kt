package com.rt03.warga

object Config {
    // Ganti dengan URL Web App Apps Script (berakhiran /exec) setelah Deploy.
    const val API_URL = "https://script.google.com/macros/s/AKfycbxfG11nTrMpHvqihoK8FOp1Thx59hez1LmjWEZUqPPl0PXve8RPyBpfVf1aKSConNCA/exec"
    const val CHANNEL_ID = "rt03_notifications"
}
