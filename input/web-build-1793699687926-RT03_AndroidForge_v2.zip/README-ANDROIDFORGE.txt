PAKET RT03 UNTUK ANDROIDFORGE
Nama aplikasi: RT03
Halaman awal: index.html
Ikon: icons/icon-512.png (atau icon-192.png)

LANGKAH:
1. Impor ZIP/folder ini ke AndroidForge.
2. Tetapkan index.html sebagai halaman awal (Start Page).
3. Nama aplikasi: RT03.
4. Pada pengaturan ikon, pilih icons/icon-512.png.
5. Build APK.

Aplikasi utama tetap berjalan online melalui Google Apps Script. Internet diperlukan.
URL Web App: https://script.google.com/macros/s/AKfycbxp7rtkzEb0ZQ5jQoafERLq4rYYDuh-sQoDWfL9vqCHqA8gpQK00oQOUtS_YfpFKfG6/exec
Code-1.gs disertakan di folder referensi sebagai cadangan backend; tidak perlu dimasukkan ke APK. Backend tetap di Google Apps Script.
