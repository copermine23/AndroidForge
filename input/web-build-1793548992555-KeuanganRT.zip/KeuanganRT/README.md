# Keuangan RT – Aplikasi Android

Pembungkus (WebView) untuk web app Apps Script Anda. `Code.gs` dan `index.html`
tidak diubah (salinan asli ada di folder `backend-appsscript/`). Aplikasi memuat URL:
`app/src/main/res/values/strings.xml` → `app_url`.

## Syarat
Deployment Apps Script harus: **Execute as: Me**, **Who has access: Anyone**
(login sudah ditangani aplikasi Anda sendiri). Jika URL /exec berubah
(deployment baru), ubah satu baris `app_url` lalu build ulang.
Perubahan di Apps Script otomatis ikut tampil tanpa build ulang
(selama URL deployment sama / deployment di-update versinya).

## Cara membuat APK

### A. Lewat GitHub (tanpa Android Studio, bisa dari HP)
1. Buat repo GitHub baru, unggah seluruh isi folder ini (termasuk `.github`).
2. Tab **Actions → Build APK → Run workflow**.
3. Setelah selesai, unduh artifact **KeuanganRT-apk** → pasang `app-release.apk`.

### B. Lewat Android Studio
1. File → Open → pilih folder ini, tunggu Gradle sync.
2. Build → Build Bundle(s)/APK(s) → Build APK(s).
3. Hasil: `app/build/outputs/apk/release/app-release.apk` (atau pakai Run untuk debug).

## Fitur bawaan
- Login/sesi/cookie berjalan normal, tampilan penuh layar.
- Unggah file (Pulihkan backup) lewat pemilih file Android.
- Unduh backup JSON / CSV → tersimpan di folder **Download**.
- Kuitansi: tampil dalam jendela dengan tombol **Cetak / Simpan PDF**.
- Pengingat WhatsApp: membuka aplikasi WhatsApp.
- Tombol back, layar offline dengan tombol "Coba lagi".
