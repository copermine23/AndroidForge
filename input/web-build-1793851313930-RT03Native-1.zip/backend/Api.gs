// ============================================================
// TAMBAHKAN file ini ke proyek Apps Script (sebagai Api.gs).
// Code.gs TIDAK perlu diubah. doGet() lama tetap melayani versi web.
// Setelah menambah file: Deploy > Manage deployments > Edit > New version
// (Execute as: Me, Who has access: Anyone). Salin URL /exec ke
// app/src/main/java/com/rt03/warga/Config.kt
// ============================================================

const API_FUNCTIONS_ = {
  login: 1, logout: 1, getDatabase: 1, saveDatabase: 1,
  daftarAkun: 1, buatAkun: 1, buatAkunWarga: 1,
  gantiPassword: 1, gantiPin: 1, resetPinWarga: 1, resetPasswordAkun: 1,
  ubahStatusAkun: 1, registerFcmToken: 1, testPushNotification: 1
};

function doPost(e) {
  let out;
  try {
    const req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    const fn = String(req.fn || '');
    if (!API_FUNCTIONS_[fn]) throw new Error('Fungsi tidak dikenal.');
    const args = Array.isArray(req.args) ? req.args : [];
    out = this[fn].apply(null, args);
    if (out === undefined) out = { ok: true };
  } catch (err) {
    out = { ok: false, error: String((err && err.message) || err) };
  }
  return ContentService.createTextOutput(JSON.stringify(out))
    .setMimeType(ContentService.MimeType.JSON);
}
