# RT03 - APK WebView (v1.1.0)

Aplikasi Android WebView untuk **RT03** (Google Apps Script - Keuangan RT).

## Perubahan v1.1.0 (anti-lag)
- **SwipeRefreshLayout dihapus** (penyebab utama lag saat scroll)
- Hardware acceleration dipaksa di Activity + WebView
- Overscroll & scrollbar dimatikan
- Zoom & long-press dimatikan
- Inject CSS performa (`-webkit-overflow-scrolling: touch`)
- largeHeap diaktifkan
- Optimasi lifecycle WebView (pause/resume timers)

## Cara Build
### AndroidForge
1. Upload ZIP ini
2. Build APK
3. Install

### Android Studio
1. Extract → buka di Android Studio
2. Sync Gradle → Build APK

## Catatan
- Pull-to-refresh sudah dihapus. Untuk refresh: tekan tombol Back sampai keluar, lalu buka lagi, atau tutup & buka aplikasi.
- Kalau masih lag, kemungkinan besar sumber lag ada di halaman Google Apps Script-nya sendiri (banyak data / DOM berat).
