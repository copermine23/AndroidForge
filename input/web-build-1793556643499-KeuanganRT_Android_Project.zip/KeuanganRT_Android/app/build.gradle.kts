plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.rt.keuangan"
    compileSdk = 35

    defaultConfig {
        applicationId = "id.rt.keuangan"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
