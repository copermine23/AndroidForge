package com.rt03.warga;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.app.Activity;
import com.google.firebase.messaging.FirebaseMessaging;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String APP_URL = "https://script.google.com/macros/s/AKfycbxJ-8n0AHdv4rGaqUUXAqWaUvmrg0dWH8f3ki3uhanHJfchsGTVhApkeIKwp_E8LPJA/exec";
    private static final String CHANNEL_ID = "rt03_warga_notifications";

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        requestNotificationPermission();
        webView = new WebView(this);
        setContentView(webView);
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setCacheMode(WebSettings.LOAD_NO_CACHE);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                sendTokenToPage();
            }
        });
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidRT03");
        webView.loadUrl(APP_URL);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                getPreferences(MODE_PRIVATE).edit().putString("fcm_token", task.getResult()).apply();
                sendTokenToPage();
            }
        });
    }

    private void sendTokenToPage() {
        if (webView == null) return;
        String token = getPreferences(MODE_PRIVATE).getString("fcm_token", "");
        if (token == null || token.isEmpty()) return;
        String js = "if (typeof window.onNativeFcmToken === 'function') { window.onNativeFcmToken('" + token + "'); }";
        webView.post(() -> webView.evaluateJavascript(js, null));
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, 301);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Notifikasi RT03", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Pengumuman RT03 dan informasi pembayaran iuran");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void requestFcmToken() { runOnUiThread(() -> sendTokenToPage()); }
        @JavascriptInterface public String getPlatform() { return "android"; }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
}
