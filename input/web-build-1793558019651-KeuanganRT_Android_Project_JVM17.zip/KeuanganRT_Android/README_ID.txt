PROYEK ANDROID KEUANGAN RT
==========================

Proyek ini adalah pembungkus Android WebView untuk Web App Google Apps Script
yang URL-nya diberikan pengguna. Data dan logika aplikasi tetap berada di
Google Apps Script/Google Drive; aplikasi memerlukan internet.

CARA MEMBANGUN APK
1. Ekstrak ZIP ini di komputer Windows/Mac/Linux.
2. Pasang Android Studio versi stabil dan Android SDK yang diminta.
3. Buka Android Studio > Open > pilih folder KeuanganRT_Android.
4. Tunggu Gradle Sync selesai. Jika diminta, pasang SDK platform 35.
5. Untuk APK uji: Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK debug biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android, buka file, lalu izinkan instalasi dari sumber
   tersebut jika Android memintanya.

UNTUK DISTRIBUSI RESMI
Gunakan Build > Generate Signed Bundle / APK dan simpan signing key dengan aman.
Jangan membagikan file keystore atau password-nya.

CATATAN PENGUJIAN
- Pastikan URL Web App masih aktif dan izin deployment Apps Script sesuai.
- Login, penyimpanan, pembaruan data, ekspor CSV, cetak kuitansi, dan unggah
  backup harus diuji pada perangkat nyata.
- File ini adalah proyek sumber, BUKAN APK yang sudah dibangun atau diuji.
- Versi ini belum menyediakan akses offline; koneksi internet dibutuhkan.
