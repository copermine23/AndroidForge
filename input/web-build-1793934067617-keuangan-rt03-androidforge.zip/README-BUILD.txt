KEUANGAN RT03 - proyek Android (Gradle) untuk dikompilasi di androidForge

Isi: aplikasi WebView yang membungkus index.html (di app/src/main/assets) dan
terhubung ke Supabase. Paket: id.rt03.keuangan, minSdk 29 (Android 10+).

Build rilis (sudah ditandatangani otomatis memakai app/rt03-release.jks):
    gradle assembleRelease      (butuh JDK 17 + Android SDK 34, Gradle 8.7)
Hasil: app/build/outputs/apk/release/app-release.apk

Kunci penanda tangan: lihat KEYSTORE-INFO.txt (simpan di tempat aman).
Untuk mengganti URL/key Supabase: edit app/src/main/assets/index.html
(cari SUPABASE_URL), lalu build ulang.
