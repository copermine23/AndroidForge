PROYEK APK WARGA RT03 — UNTUK ANDROIDFORGE

Isi ZIP ini adalah proyek Android Gradle (Kotlin) dengan:
- WebView yang membuka aplikasi Google Apps Script RT03.
- Package ID: com.rt03.warga (sesuai Firebase project yang tersedia).
- Firebase Cloud Messaging SDK dan layanan penerima notifikasi.
- Izin notifikasi Android 13+.

CARA BUILD DI ANDROIDFORGE
1. Buka https://professional-x.github.io/AndroidForge/
2. Hubungkan GitHub sesuai langkah pada situs AndroidForge.
3. Upload ZIP ini (jangan diekstrak terlebih dahulu).
4. Pilih Android dan varian debug/auto, lalu tekan Build.
5. Setelah selesai, buka run GitHub Actions dan unduh artifact AndroidForge-APKs.
6. Ekstrak artifact dan instal APK debug pada ponsel.

PENTING — STATUS NOTIFIKASI
APK ini sudah memiliki Firebase Messaging SDK dan dapat menerima pesan FCM yang dikirim oleh server.
Namun notifikasi iuran otomatis BELUM aktif hanya dengan membuat APK.
Backend Google Apps Script perlu ditambah:
- fungsi pendaftaran token FCM yang mengaitkan token dengan akun KK yang sedang login;
- pengiriman pesan Firebase HTTP v1 dari server saat ada iuran/pembayaran/pengumuman.
Kunci service account Firebase harus disimpan di Script Properties Google Apps Script, bukan di APK atau HTML.
Jangan pernah membagikan PIN, password, GitHub token, atau private key.

CATATAN
- URL Web App RT03 sudah dipasang pada aplikasi.
- Firebase google-services.json sudah disertakan untuk package com.rt03.warga.
- APK debug akan memakai application ID com.rt03.warga.debug. Untuk produksi gunakan varian release agar application ID menjadi com.rt03.warga.
