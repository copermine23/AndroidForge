# Aplikasi RT03 (Android WebView)

Project ini membungkus aplikasi web RT03 yang tetap berjalan **online** melalui deployment Google Apps Script. Koneksi internet diperlukan; aplikasi tidak menyimpan salinan offline dari dashboard.

## Perubahan versi 1.1.0
- Nama aplikasi dan label Android menjadi **RT03**.
- Ikon launcher menggunakan gambar RT03 yang Anda kirim.
- Splash screen hijau dengan identitas RT03: splash native Android 12+ dan tampilan awal untuk Android versi sebelumnya.
- Penguatan konfigurasi: HTTPS saja, cleartext HTTP ditolak, akses file lokal WebView dinonaktifkan, backup Android dinonaktifkan.
- Dukungan signing release dengan keystore pribadi.

## Build di AndroidForge
1. Ekstrak ZIP ini, lalu impor folder `KeuanganRT-AndroidForge` sebagai project Android/Gradle.
2. Gunakan JDK 17 dan Android SDK 34 (minimum SDK 23).
3. Sinkronkan Gradle lalu jalankan build APK.
4. Untuk APK rilis yang dapat dipasang dan diperbarui dengan identitas penandatanganan yang konsisten, gunakan keystore RT03 yang sudah disertakan.

## Keystore release sudah disertakan
- File keystore: `rt03-release.jks`
- Alias: `rt03`
- Konfigurasi Gradle: `keystore.properties` sudah diisi.
- Password tersimpan pada `CATATAN-KEYSTORE.txt` di dalam ZIP ini.
- Impor seluruh folder project dan pertahankan ketiga file tersebut di folder utama project.
- Pilih/build variant `release` agar APK ditandatangani dengan keystore RT03 ini.

## Catatan keamanan dan operasional
- Simpan keystore dan password secara pribadi; jangan unggah ke chat atau repositori publik.
- Gunakan URL deployment Apps Script HTTPS yang tepercaya. Aplikasi tetap membutuhkan internet dan akun/izin yang sesuai pada layanan web.
- Perubahan URL atau deployment Apps Script dilakukan pada konstanta `APP_URL` di `MainActivity.java`.
- ZIP ini adalah **source project**, bukan APK yang sudah dibangun atau diuji pada perangkat.
