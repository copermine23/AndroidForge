package id.keuanganrt.app;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.Arrays;
import java.util.HashSet;

/**
 * Pembungkus (WebView) untuk web app Apps Script "Keuangan RT".
 * Kode web (Code.gs / index.html) TIDAK diubah sama sekali; aplikasi hanya memuat URL /exec.
 */
public class MainActivity extends AppCompatActivity {

    private WebView web;
    private FrameLayout root;
    private LinearLayout popupLayer;
    private WebView popup;
    private ValueCallback<Uri[]> filePathCallback;
    private String appUrl;

    private final ActivityResultLauncher<Intent> fileChooser =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (filePathCallback == null) return;
                Uri[] uris = WebChromeClient.FileChooserParams.parseResult(
                        result.getResultCode(), result.getData());
                filePathCallback.onReceiveValue(uris);
                filePathCallback = null;
            });

    /**
     * Skrip yang disisipkan ke setiap frame (termasuk iframe Apps Script) agar unduhan
     * berbasis blob (backup JSON, ekspor CSV) bisa disimpan ke perangkat.
     */
    private static final String HOOK_JS =
            "(function(){if(window.__krtHooked)return;window.__krtHooked=true;"
          + "var blobs={};var oc=URL.createObjectURL;"
          + "URL.createObjectURL=function(b){var u=oc.call(URL,b);try{blobs[u]=b}catch(e){}return u};"
          + "var ck=HTMLAnchorElement.prototype.click;"
          + "HTMLAnchorElement.prototype.click=function(){var a=this;"
          + "if(a.hasAttribute('download')&&a.href&&a.href.indexOf('blob:')===0&&window.KeuanganBridge){"
          + "var b=blobs[a.href];if(b){var r=new FileReader();"
          + "r.onloadend=function(){var s=String(r.result||'');var i=s.indexOf(',');"
          + "window.KeuanganBridge.saveFile(a.getAttribute('download')||'file',"
          + "b.type||'application/octet-stream',s.slice(i+1));};"
          + "r.readAsDataURL(b);return;}}"
          + "return ck.apply(this,arguments);};})();";

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        appUrl = getString(R.string.app_url);

        root = new FrameLayout(this);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        configure(web);
        web.addJavascriptInterface(new Bridge(), "KeuanganBridge");

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(web, HOOK_JS, new HashSet<>(Arrays.asList(
                    "https://script.google.com",
                    "https://*.google.com",
                    "https://*.googleusercontent.com")));
        }

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                return handleExternal(req.getUrl());
            }

            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) showOffline();
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = cb;
                try {
                    fileChooser.launch(params.createIntent());
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onCreateWindow(WebView v, boolean isDialog, boolean isUserGesture,
                                          Message resultMsg) {
                return openPopup(resultMsg);
            }
        });

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (popup != null) closePopup();
                else if (web.canGoBack()) web.goBack();
                else finish();
            }
        });

        if (savedInstanceState != null) web.restoreState(savedInstanceState);
        else web.loadUrl(appUrl);
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setAllowFileAccess(false);
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(w, true);
    }

    /** true = ditangani (dibuka di aplikasi lain), false = biarkan WebView memuat. */
    private boolean handleExternal(Uri u) {
        String scheme = u.getScheme() == null ? "" : u.getScheme();
        String host = u.getHost() == null ? "" : u.getHost();
        boolean isWeb = scheme.equals("http") || scheme.equals("https");
        if (scheme.equals("about") || scheme.equals("blob") || scheme.equals("data")) return false;
        if (isWeb && (host.equals("google.com") || host.endsWith(".google.com")
                || host.endsWith(".googleusercontent.com") || host.endsWith(".gstatic.com"))) {
            return false;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (Exception e) {
            Toast.makeText(this, "Tidak ada aplikasi untuk membuka tautan ini",
                    Toast.LENGTH_SHORT).show();
        }
        return true;
    }

    // ---------- Jendela popup (kuitansi, tautan WhatsApp) ----------
    @SuppressLint("SetJavaScriptEnabled")
    private boolean openPopup(Message resultMsg) {
        if (popup != null) closePopup();
        popup = new WebView(this);
        configure(popup);
        popup.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                if (handleExternal(req.getUrl())) {
                    v.post(MainActivity.this::closePopup);
                    return true;
                }
                return false;
            }

            @Override
            public void onPageStarted(WebView v, String url, android.graphics.Bitmap f) {
                if (url != null && url.startsWith("http") && handleExternal(Uri.parse(url))) {
                    v.post(MainActivity.this::closePopup);
                }
            }
        });
        popup.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onCloseWindow(WebView w) {
                closePopup();
            }
        });

        popupLayer = new LinearLayout(this);
        popupLayer.setOrientation(LinearLayout.VERTICAL);
        popupLayer.setBackgroundColor(0xFFFFFFFF);
        popupLayer.setClickable(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xFFBFE6D2);
        Button close = new Button(this);
        close.setText("Tutup");
        close.setOnClickListener(v -> closePopup());
        Button print = new Button(this);
        print.setText("Cetak / Simpan PDF");
        print.setOnClickListener(v -> printPopup());
        bar.addView(close);
        bar.addView(print);

        popupLayer.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        popupLayer.addView(popup, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(popupLayer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        WebView.WebViewTransport t = (WebView.WebViewTransport) resultMsg.obj;
        t.setWebView(popup);
        resultMsg.sendToTarget();
        return true;
    }

    private void closePopup() {
        if (popupLayer != null) {
            root.removeView(popupLayer);
            popupLayer = null;
        }
        if (popup != null) {
            popup.destroy();
            popup = null;
        }
    }

    private void printPopup() {
        if (popup == null) return;
        PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
        pm.print("Kuitansi", popup.createPrintDocumentAdapter("Kuitansi"),
                new PrintAttributes.Builder().build());
    }

    // ---------- Offline ----------
    private void showOffline() {
        String html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'></head>"
                + "<body style='font-family:sans-serif;background:#bfe6d2;color:#10231a;"
                + "text-align:center;padding:48px 24px'>"
                + "<h2>Tidak ada koneksi</h2><p>Aplikasi Keuangan RT membutuhkan internet. "
                + "Periksa koneksi lalu coba lagi.</p>"
                + "<p><a href='" + appUrl + "' style='display:inline-block;padding:12px 22px;"
                + "background:#14532d;color:#fff;border-radius:12px;text-decoration:none'>"
                + "Coba lagi</a></p></body></html>";
        web.loadDataWithBaseURL(appUrl, html, "text/html", "utf-8", null);
    }

    // ---------- Simpan file unduhan ----------
    private class Bridge {
        @JavascriptInterface
        public void saveFile(String name, String mime, String base64) {
            try {
                byte[] data = Base64.decode(base64, Base64.DEFAULT);
                String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
                String where;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues cv = new ContentValues();
                    cv.put(MediaStore.Downloads.DISPLAY_NAME, safe);
                    cv.put(MediaStore.Downloads.MIME_TYPE, mime);
                    cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                    Uri uri = getContentResolver().insert(
                            MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (uri == null) throw new Exception("insert gagal");
                    try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                        os.write(data);
                    }
                    where = "folder Download";
                } else {
                    File dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                    File f = new File(dir, safe);
                    try (FileOutputStream os = new FileOutputStream(f)) {
                        os.write(data);
                    }
                    where = f.getAbsolutePath();
                }
                final String msg = "Tersimpan: " + safe + " (" + where + ")";
                runOnUiThread(() -> Toast.makeText(MainActivity.this, msg,
                        Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Gagal menyimpan file", Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }
}
