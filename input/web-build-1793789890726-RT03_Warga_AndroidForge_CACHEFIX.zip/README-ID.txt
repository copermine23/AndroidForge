PROYEK APK WARGA RT03 — ANDROIDFORGE (PERBAIKAN CACHE)

Proyek Android Gradle Kotlin ini membuka URL Web App RT03 yang sama dengan browser.
Cache WebView dinonaktifkan dan cache lokal dibersihkan saat aplikasi dijalankan agar halaman terbaru lebih cepat tampil.
Package ID: com.rt03.warga
Firebase Messaging SDK sudah disertakan.

BUILD
1. Buka https://professional-x.github.io/AndroidForge/
2. Upload ZIP ini tanpa diekstrak.
3. Pilih Android, jalankan Build, lalu unduh APK artifact.
4. Saat memasang APK baru, izinkan pemasangan pembaruan aplikasi. Jika masih tertahan, hapus aplikasi lama lalu instal APK baru (pastikan akun login masih diketahui).

CATATAN NOTIFIKASI
Notifikasi yang tampil di halaman web (misalnya kartu pemberitahuan/tunggakan) berasal dari Web App dan akan mengikuti versi deployment yang sedang aktif. Firebase Messaging SDK pada APK belum otomatis mengaktifkan push notification; backend Apps Script masih perlu fungsi registrasi token perangkat dan pengiriman pesan FCM.
