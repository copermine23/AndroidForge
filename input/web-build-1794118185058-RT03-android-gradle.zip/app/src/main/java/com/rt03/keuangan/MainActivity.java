package com.rt03.keuangan;

import android.app.Activity;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Membungkus aplikasi web (GitHub Pages; cadangan: assets/www/index.html) dalam WebView.
 * Menyediakan "AndroidBridge" yang dipakai aplikasi web:
 *   - getPushToken()  : token notifikasi (kosong; FCM belum dipasang)
 *   - saveFile(...)   : simpan CSV/berkas lewat pemilih lokasi Android
 *   - printHtml(...)  : cetak/simpan PDF kuitansi
 */
public class MainActivity extends Activity {

    // Aplikasi dimuat dari GitHub Pages, sehingga update cukup lewat GitHub (tanpa build APK ulang).
    private static final String SITE = "https://copermine23.github.io/RT03/";
    // Cadangan bila GitHub Pages tidak bisa dibuka (mis. tanpa internet saat pertama dibuka).
    private static final String FALLBACK_URL = "file:///android_asset/www/index.html";
    private static final String START_URL = SITE;
    private static final int REQ_FILE = 1001;
    private static final int REQ_SAVE = 1002;

    private WebView web;
    private WebView printView; // dipegang agar tidak dibersihkan GC saat proses cetak
    private ValueCallback<Uri[]> fileCallback;
    private String pendingName;
    private String pendingContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        setContentView(web);
        configure(web);

        web.setWebViewClient(new ExternalAwareClient(null));
        web.setWebChromeClient(new WebChromeClient() {
            // Pemilih berkas (mis. "Pulihkan backup")
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (fileCallback != null) {
                    fileCallback.onReceiveValue(null);
                }
                fileCallback = callback;
                try {
                    startActivityForResult(params.createIntent(), REQ_FILE);
                } catch (ActivityNotFoundException e) {
                    fileCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak ada aplikasi pemilih berkas.", Toast.LENGTH_LONG).show();
                    return false;
                }
                return true;
            }

            // window.open(...) : dipakai untuk kuitansi dan tautan WhatsApp
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture,
                                          Message resultMsg) {
                final WebView popup = new WebView(MainActivity.this);
                configure(popup);
                popup.addJavascriptInterface(new Bridge(), "AndroidBridge");

                final Dialog dialog = new Dialog(MainActivity.this,
                        android.R.style.Theme_Material_Light_NoActionBar);
                dialog.setContentView(popup);
                dialog.setOnDismissListener(d -> popup.destroy());

                popup.setWebViewClient(new ExternalAwareClient(dialog));
                popup.setWebChromeClient(new WebChromeClient() {
                    @Override
                    public void onCloseWindow(WebView window) {
                        dialog.dismiss();
                    }
                });

                WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                dialog.show();
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "AndroidBridge");

        web.loadUrl(START_URL);
    }

    private void configure(WebView w) {
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setBuiltInZoomControls(false);
        s.setSupportZoom(false);
    }

    private static boolean isInternal(String url) {
        return url == null
                || url.startsWith(SITE)
                || url.startsWith("file:///android_asset/")
                || url.startsWith("about:")
                || url.startsWith("data:")
                || url.startsWith("blob:")
                || url.startsWith("javascript:");
    }

    private void openExternal(String url) {
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Tidak dapat membuka tautan.", Toast.LENGTH_LONG).show();
        }
    }

    /** Tautan di luar aplikasi (https, tel, whatsapp, mailto...) dibuka di aplikasi lain. */
    private class ExternalAwareClient extends WebViewClient {
        private final Dialog owner;

        ExternalAwareClient(Dialog owner) {
            this.owner = owner;
        }

        private boolean handle(WebView view, String url) {
            if (isInternal(url)) {
                return false;
            }
            view.stopLoading();
            openExternal(url);
            if (owner != null) {
                owner.dismiss();
            }
            return true;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
            return handle(view, request.getUrl().toString());
        }

        @Override
        public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
            if (owner == null && request.isForMainFrame()
                    && request.getUrl().toString().startsWith(SITE)) {
                view.loadUrl(FALLBACK_URL);
            }
        }

        @Override
        public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
            if (!isInternal(url)) {
                handle(view, url);
            }
        }
    }

    /** Jembatan JavaScript -> Android (nama di web: window.AndroidBridge). */
    public class Bridge {
        @JavascriptInterface
        public String getPushToken() {
            return ""; // belum ada FCM; aplikasi tetap berjalan tanpa notifikasi push
        }

        @JavascriptInterface
        public void saveFile(final String name, final String content, final String type) {
            runOnUiThread(() -> {
                pendingName = name;
                pendingContent = content;
                String mime = (type == null || type.trim().isEmpty()) ? "text/csv" : type.split(";")[0].trim();
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType(mime);
                i.putExtra(Intent.EXTRA_TITLE, name);
                try {
                    startActivityForResult(i, REQ_SAVE);
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih lokasi simpan.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(() -> doPrint(html));
        }
    }

    private void doPrint(String html) {
        WebView pw = new WebView(this); // JavaScript sengaja dimatikan di sini
        pw.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                String job = getString(R.string.app_name) + " - Kuitansi";
                PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(job);
                pm.print(job, adapter, new PrintAttributes.Builder().build());
            }
        });
        printView = pw;
        pw.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(
                        WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        if (requestCode == REQ_SAVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null && pendingContent != null) {
                try (OutputStream os = getContentResolver().openOutputStream(data.getData())) {
                    os.write(pendingContent.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "File tersimpan.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Gagal menyimpan file.", Toast.LENGTH_LONG).show();
                }
            }
            pendingContent = null;
            pendingName = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) {
            web.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
        }
        super.onDestroy();
    }
}
